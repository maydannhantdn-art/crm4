import { create } from 'zustand';
import { Task } from '../types';
import { dataStore } from './dataStore';

interface TaskStore {
  tasks: Task[];
  loading: boolean;
  error: string | null;
  fetchTasks: () => Promise<void>;
  setTasks: (tasks: Task[]) => void;
  addTask: (task: Task) => Promise<void>;
  updateTask: (task: Task) => Promise<void>;
  deleteTask: (taskId: string) => Promise<void>;
  addComment: (taskId: string, comment: { userName: string; content: string }) => Promise<void>;
  addSubtask: (taskId: string, title: string) => Promise<void>;
  toggleSubtask: (taskId: string, subtaskId: string) => Promise<void>;
  addAttachment: (taskId: string, name: string, url: string, size?: string) => Promise<void>;
  runAutomation: (taskId: string, triggerType: string) => void;
}

export const useTaskStore = create<TaskStore>((set, get) => ({
  tasks: [],
  loading: false,
  error: null,

  fetchTasks: async () => {
    set({ loading: true });
    try {
      const data = await dataStore.getTasks();
      // Enrich initial values if missing
      const enriched = data.map((task: Task) => ({
        ...task,
        status: task.status || 'todo',
        priority: task.priority || 'medium',
        progress: typeof task.progress === 'number' ? task.progress : 0,
        labels: task.labels || [],
        dependencies: task.dependencies || [],
        subtasks: task.subtasks || [],
        attachments: task.attachments || [],
        comments: task.comments || [],
        activity_logs: task.activity_logs || [],
        estimated_hours: task.estimated_hours || 8,
        actual_hours: task.actual_hours || 0,
        KPI_weight: task.KPI_weight || 50,
        SLA_level: task.SLA_level || 'medium',
        workflow_stage: task.workflow_stage || 'Định hình',
      }));
      set({ tasks: enriched, loading: false });
    } catch (err: any) {
      set({ error: err.message, loading: false });
    }
  },

  setTasks: (tasks: Task[]) => set({ tasks }),

  addTask: async (task: Task) => {
    const enriched: Task = {
      ...task,
      labels: task.labels || [],
      dependencies: task.dependencies || [],
      subtasks: task.subtasks || [],
      attachments: task.attachments || [],
      comments: task.comments || [],
      activity_logs: [
        {
          id: 'log_' + Date.now(),
          action: 'Khởi tạo tác vụ nhiệm vụ mới',
          performedBy: task.assignedTo || 'Sếp',
          timestamp: new Date().toISOString(),
        },
      ],
      estimated_hours: task.estimated_hours || 8,
      actual_hours: 0,
      KPI_weight: task.KPI_weight || 50,
      SLA_level: task.SLA_level || 'medium',
      workflow_stage: 'Khởi tạo',
    };

    set(state => ({ tasks: [enriched, ...state.tasks] }));
    await dataStore.saveTask(enriched);
    get().runAutomation(enriched.id, 'create');
  },

  updateTask: async (task: Task) => {
    set(state => ({
      tasks: state.tasks.map(t => (t.id === task.id ? { ...t, ...task } : t)),
    }));
    await dataStore.saveTask(task);
    get().runAutomation(task.id, 'update');
  },

  deleteTask: async (taskId: string) => {
    set(state => ({
      tasks: state.tasks.filter(t => t.id !== taskId),
    }));
    await dataStore.deleteTask(taskId);
  },

  addComment: async (taskId: string, comment: { userName: string; content: string }) => {
    const newComment = {
      id: 'c_' + Date.now(),
      userName: comment.userName,
      content: comment.content,
      createdAt: new Date().toISOString(),
    };

    set(state => ({
      tasks: state.tasks.map(t => {
        if (t.id === taskId) {
          const updatedComments = [...(t.comments || []), newComment];
          const updatedLogs = [
            ...(t.activity_logs || []),
            {
              id: 'log_' + Date.now(),
              action: `Bình luận mới bởi ${comment.userName}`,
              performedBy: comment.userName,
              timestamp: new Date().toISOString(),
            },
          ];
          const nextTask = { ...t, comments: updatedComments, activity_logs: updatedLogs };
          dataStore.saveTask(nextTask); // Async save
          return nextTask;
        }
        return t;
      }),
    }));
  },

  addSubtask: async (taskId: string, title: string) => {
    const newSub = {
      id: 'sub_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      title,
      done: false,
    };

    set(state => ({
      tasks: state.tasks.map(t => {
        if (t.id === taskId) {
          const updatedSubtasks = [...(t.subtasks || []), newSub];
          const nextTask = { ...t, subtasks: updatedSubtasks };
          dataStore.saveTask(nextTask);
          return nextTask;
        }
        return t;
      }),
    }));
  },

  toggleSubtask: async (taskId: string, subtaskId: string) => {
    set(state => ({
      tasks: state.tasks.map(t => {
        if (t.id === taskId) {
          const updatedSubtasks = (t.subtasks || []).map(sub =>
            sub.id === subtaskId ? { ...sub, done: !sub.done } : sub
          );
          // Auto update progress percent based on subtasks
          const doneCount = updatedSubtasks.filter(s => s.done).length;
          const progress = updatedSubtasks.length > 0 
            ? Math.round((doneCount / updatedSubtasks.length) * 100) 
            : t.progress;

          const nextTask = { 
            ...t, 
            subtasks: updatedSubtasks, 
            progress,
            status: progress === 100 ? ('done' as const) : t.status
          };
          dataStore.saveTask(nextTask);
          return nextTask;
        }
        return t;
      }),
    }));
  },

  addAttachment: async (taskId: string, name: string, url: string, size?: string) => {
    const newAttach = {
      id: 'att_' + Date.now(),
      name,
      url,
      size,
    };

    set(state => ({
      tasks: state.tasks.map(t => {
        if (t.id === taskId) {
          const updatedAttachments = [...(t.attachments || []), newAttach];
          const nextTask = { ...t, attachments: updatedAttachments };
          dataStore.saveTask(nextTask);
          return nextTask;
        }
        return t;
      }),
    }));
  },

  runAutomation: (taskId: string, triggerType: string) => {
    const task = get().tasks.find(t => t.id === taskId);
    if (!task) return;

    // Trigger action simulation
    if (triggerType === 'create') {
      console.log(`[Task Automation] New task created: ${task.title}. Notifying assignee: ${task.assignedTo}`);
    } else if (triggerType === 'update') {
      if (task.status === 'done' && task.progress === 100) {
        console.log(`[Task Automation] Task completed: ${task.title}. Unlocking dependent tasks if any.`);
      }
    }
  },
}));
