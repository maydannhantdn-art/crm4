import { databases, DATABASE_ID, realtime } from './appwrite';
import { Query } from 'appwrite';
import { Task, Project, KPIs, User, EmployeeWorkload, TaskRiskScore, ZaloOAConfig, ZaloWebhookMessage, Lead, Notification } from '../types';

// Helper to manage localStorage cache
const getLocalCache = <T>(key: string, fallback: T): T => {
  try {
    const data = localStorage.getItem(`tindan_${key}`);
    return data ? JSON.parse(data) : fallback;
  } catch {
    return fallback;
  }
};

const setLocalCache = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(`tindan_${key}`, JSON.stringify(value));
  } catch {
    // Ignore
  }
};

// Rich, realistic initial mock data for Tín Dân Company
const initialUsers: User[] = [
  { 
    id: '1', 
    name: 'Admin', 
    email: 'admin@tindan.com', 
    role: 'CEO / Quản lý tối cao', 
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
    password: '123456',
    permissions: ['workspace', 'inbox', 'tasks', 'projects', 'teams', 'crm', 'ai-command', 'knowledge', 'kpis', 'automation', 'notifications', 'files', 'settings']
  },
  { 
    id: '2', 
    name: 'Nguyễn Văn Đạt', 
    email: 'dat.nguyen@tindan.com', 
    role: 'Trưởng phòng Phát triển', 
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    password: '123',
    permissions: ['workspace', 'tasks', 'projects', 'knowledge', 'notifications', 'files']
  },
  { 
    id: '3', 
    name: 'Lê Thị Mỹ Duyên (AI Chatbot)', 
    email: 'duyen.ai@tindan.com', 
    role: 'Đại diện Chatbot', 
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    password: '123',
    permissions: ['workspace', 'inbox', 'crm', 'knowledge']
  },
  { 
    id: '4', 
    name: 'Phạm Hồng Nam', 
    email: 'nam.pham@tindan.com', 
    role: 'Chuyên viên Tối ưu CRO', 
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    password: '123',
    permissions: ['workspace', 'tasks', 'knowledge', 'kpis', 'notifications', 'files']
  }
];

const initialProjects: Project[] = [];

const initialTasks: Task[] = [];

const initialKPIs: KPIs[] = [];

const initialWorkloads: EmployeeWorkload[] = [];

const initialRisks: TaskRiskScore[] = [];

const initialLeads: Lead[] = [];

const initialNotifications: Notification[] = [];

const initialZaloOAs: ZaloOAConfig[] = [];

// Automatic one-time purge of previously stored demo datasets
try {
  if (localStorage.getItem('tindan_demo_purged_v4') !== 'true') {
    const keysToPurge = [
      'tindan_tasks',
      'tindan_projects',
      'tindan_kpis',
      'tindan_employee_workload',
      'tindan_task_risk',
      'tindan_chatbot_duyen_leads',
      'tindan_notifications',
      'tindan_zalo_oa_configurations',
      'tindan_zalo_webhook_messages'
    ];
    keysToPurge.forEach(k => localStorage.removeItem(k));
    localStorage.setItem('tindan_demo_purged_v4', 'true');
  }
} catch (e) {}

// Combine all mocks for easy setup
const getCachedCollection = <T>(collectionId: string, initialData: T[]): T[] => {
  return getLocalCache<T[]>(collectionId, initialData);
};

let hasLoggedOfflineMode = false;
let isOnline = (() => {
  try {
    return sessionStorage.getItem('tindan_appwrite_offline') !== 'true';
  } catch {
    return true;
  }
})();

const setOfflineMode = () => {
  if (isOnline) {
    isOnline = false;
    try {
      sessionStorage.setItem('tindan_appwrite_offline', 'true');
    } catch {}
    console.info('[dataStore] Appwrite Cloud appears offline. Silently switching to high-performance local database cache mode.');
  }
};

const withTimeout = <T>(promise: Promise<T>, timeoutMs: number = 1500): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => 
      setTimeout(() => reject(new Error('Connection timeout')), timeoutMs)
    )
  ]);
};

const syncCachedDataToCloud = async () => {
  if (!isOnline) return;
  console.log('[dataStore] Khởi phát đồng bộ ngầm dữ liệu từ Local Cache lên Appwrite Cloud...');
  
  const collections = ['tasks', 'projects', 'users', 'kpis', 'chatbot_duyen_leads', 'notifications'];
  for (const collectionId of collections) {
    try {
      const local = getLocalCache<any>(collectionId, []);
      if (!Array.isArray(local) || local.length === 0) continue;
      
      for (const item of local) {
        if (!item.id) continue;
        const cloudItem = sanitizeForCloud(collectionId, item);
        try {
          // Attempt silent update on cloud
          await withTimeout(databases.updateDocument(DATABASE_ID, collectionId, item.id, cloudItem), 1200);
        } catch (err: any) {
          // If document does not exist, create it
          if (err?.code === 404 || err?.message?.includes('not found')) {
            try {
              await withTimeout(databases.createDocument(DATABASE_ID, collectionId, item.id, cloudItem), 1200);
            } catch (createErr) {
              // Ignore creation failures for specific rows
            }
          }
        }
      }
    } catch (e) {
      // General safety block for each collection sync loop
    }
  }
  console.log('[dataStore] Tiến trình đồng bộ cache cục bộ lên Cloud hoàn tất thành công!');
};

const sanitizeForCloud = (collectionId: string, item: any): any => {
  const clean = { ...item };
  // Clean all fields starting with $ completely
  Object.keys(clean).forEach(k => {
    if (k.startsWith('$')) {
      delete clean[k];
    }
  });

  // Always remove the redundant 'id' field, because Appwrite maps the document ID to $id
  // and does not allow custom attributes named 'id' unless defined inside the schema.
  if ('id' in clean) {
    delete clean.id;
  }

  // Schema validations for Appwrite Cloud to match registered attributes on the online DB
  if (collectionId === 'projects') {
    const allowed = ['name', 'description', 'manager', 'startDate', 'endDate', 'status'];
    Object.keys(clean).forEach(k => {
      if (!allowed.includes(k)) {
        delete clean[k];
      }
    });
  } else if (collectionId === 'tasks') {
    const allowed = ['title', 'description', 'status', 'priority', 'dueDate', 'assignedTo', 'projectId', 'progress'];
    Object.keys(clean).forEach(k => {
      if (!allowed.includes(k)) {
        delete clean[k];
      }
    });
  } else if (collectionId === 'kpis') {
    const allowed = ['name', 'target', 'current', 'unit', 'period'];
    Object.keys(clean).forEach(k => {
      if (!allowed.includes(k)) {
        delete clean[k];
      }
    });
  } else if (collectionId === 'users') {
    const allowed = ['name', 'email', 'role', 'avatar', 'password', 'permissions', 'department'];
    Object.keys(clean).forEach(k => {
      if (!allowed.includes(k)) {
        delete clean[k];
      }
    });
  }
  return clean;
};

export const dataStore = {
  // Generic Read Operation
  getDocuments: async <T>(collectionId: string, defaultData: T[]): Promise<T[]> => {
    if (!isOnline) {
      return getCachedCollection<T>(collectionId, defaultData);
    }
    try {
      const response = await withTimeout(databases.listDocuments(DATABASE_ID, collectionId));
      const list = response.documents.map(d => ({ id: d.$id, ...d } as unknown as T));
      
      const local = getCachedCollection<T>(collectionId, defaultData);
      const merged = list.map(cloudDoc => {
        const localDoc = local.find((x: any) => x.id === (cloudDoc as any).id);
        return localDoc ? { ...localDoc, ...cloudDoc } : cloudDoc;
      });

      // Keep newly created local documents that haven't synced to Cloud yet
      const cloudIds = new Set(list.map(d => (d as any).id));
      const newlyCreated = local.filter((x: any) => x.id && !cloudIds.has(x.id));
      const finalized = [...merged, ...newlyCreated];

      setLocalCache(collectionId, finalized);
      return finalized;
    } catch (err: any) {
      const errMsg = err?.message || String(err);
      if (
        errMsg.includes('Failed to fetch') || 
        errMsg.includes('fetch') || 
        errMsg.includes('Network Error') || 
        errMsg.includes('timeout') ||
        err.name === 'TypeError'
      ) {
        setOfflineMode();
      }
      if (!hasLoggedOfflineMode) {
        console.info('[dataStore] Initiated Offline-First local database cache fallbacks for collections.');
        hasLoggedOfflineMode = true;
      }
      return getCachedCollection<T>(collectionId, defaultData);
    }
  },

  // Generic Save / Update Operation
  saveDocument: async <T extends { id: string }>(collectionId: string, docId: string, item: any, defaultData: T[]): Promise<any> => {
    const list = getCachedCollection<T>(collectionId, defaultData);
    const index = list.findIndex(x => x.id === docId);
    if (index >= 0) {
      list[index] = { ...list[index], ...item };
    } else {
      list.unshift({ id: docId, ...item });
    }
    setLocalCache(collectionId, list);

    if (!isOnline) {
      return item;
    }

    const cloudItem = sanitizeForCloud(collectionId, item);

    try {
      try {
        // Attempt update with short timeout
        return await withTimeout(databases.updateDocument(DATABASE_ID, collectionId, docId, cloudItem));
      } catch (innerErr: any) {
        const innerMsg = innerErr?.message || '';
        if (
          innerMsg.includes('Failed to fetch') || 
          innerMsg.includes('fetch') || 
          innerMsg.includes('Network Error') || 
          innerMsg.includes('timeout') ||
          innerErr.name === 'TypeError'
        ) {
          setOfflineMode();
          return item;
        }
        // Attempt create if update fails
        return await withTimeout(databases.createDocument(DATABASE_ID, collectionId, docId, cloudItem));
      }
    } catch (err: any) {
      const errMsg = err?.message || '';
      if (
        errMsg.includes('Failed to fetch') || 
        errMsg.includes('fetch') || 
        errMsg.includes('Network Error') || 
        errMsg.includes('timeout') ||
        err.name === 'TypeError'
      ) {
        setOfflineMode();
      } else {
        console.info(`[dataStore] Local-first write succeeded for ${collectionId}. Cloud details: ${err.message}`);
      }
      return item;
    }
  },

  // Generic Delete Operation
  deleteDocument: async <T extends { id: string }>(collectionId: string, docId: string, defaultData: T[]): Promise<boolean> => {
    const list = getCachedCollection<T>(collectionId, defaultData);
    const updated = list.filter(x => x.id !== docId);
    setLocalCache(collectionId, updated);

    if (!isOnline) {
      return true;
    }

    try {
      await withTimeout(databases.deleteDocument(DATABASE_ID, collectionId, docId));
      return true;
    } catch (err: any) {
      const errMsg = err?.message || '';
      if (
        errMsg.includes('Failed to fetch') || 
        errMsg.includes('fetch') || 
        errMsg.includes('Network Error') || 
        errMsg.includes('timeout') ||
        err.name === 'TypeError'
      ) {
        setOfflineMode();
      } else {
        console.info(`[dataStore] Local-first delete succeeded for ${collectionId}. Cloud details: ${err.message}`);
      }
      return true;
    }
  },

  // Specialized Realtime Subscription Listener Wrapper
  subscribeToCollection: (collectionId: string, onUpdate: (data: any[]) => void, _defaultData: any[]): (() => void) => {
    if (!isOnline) {
      return () => {};
    }
    try {
      const channel = `databases.${DATABASE_ID}.collections.${collectionId}.documents`;
      const subscribeToken = realtime.subscribe(channel, (_response: any) => {
        if (!isOnline) return;
        // Reload documents on write event
        withTimeout(databases.listDocuments(DATABASE_ID, collectionId)).then((res) => {
          const list = res.documents.map(d => ({ id: d.$id, ...d }));
          setLocalCache(collectionId, list);
          onUpdate(list);
        }).catch(() => {});
      });

      return () => {
        if (typeof subscribeToken === 'function') {
          (subscribeToken as any)();
        } else if (subscribeToken && typeof (subscribeToken as any).unsubscribe === 'function') {
          (subscribeToken as any).unsubscribe();
        }
      };
    } catch {
      return () => {};
    }
  },

  // 1. TAM QUẢN: NHIỆM VỤ, DỰ ÁN, KPIS
  getTasks: async (): Promise<Task[]> => dataStore.getDocuments<Task>('tasks', initialTasks),
  saveTask: async (task: Task): Promise<Task> => dataStore.saveDocument<Task>('tasks', task.id, task, initialTasks),
  deleteTask: async (id: string): Promise<boolean> => dataStore.deleteDocument<Task>('tasks', id, initialTasks),

  getProjects: async (): Promise<Project[]> => dataStore.getDocuments<Project>('projects', initialProjects),
  saveProject: async (proj: Project): Promise<Project> => dataStore.saveDocument<Project>('projects', proj.id, proj, initialProjects),

  getKPIs: async (): Promise<KPIs[]> => dataStore.getDocuments<KPIs>('kpis', initialKPIs),
  saveKPI: async (kpi: KPIs): Promise<KPIs> => dataStore.saveDocument<KPIs>('kpis', kpi.id, kpi, initialKPIs),

  getUsers: async (): Promise<User[]> => dataStore.getDocuments<User>('users', initialUsers),

  // Workloads
  getWorkloads: async (): Promise<EmployeeWorkload[]> => dataStore.getDocuments<EmployeeWorkload>('employee_workload', initialWorkloads),
  // Risks
  getRiskScores: async (): Promise<TaskRiskScore[]> => dataStore.getDocuments<TaskRiskScore>('task_risk', initialRisks),

  // 2. LEAD VỒN, WEBHOOKS, ZALO OA
  getLeads: async (): Promise<Lead[]> => dataStore.getDocuments<Lead>('chatbot_duyen_leads', initialLeads),
  saveLead: async (lead: Lead): Promise<Lead> => dataStore.saveDocument<Lead>('chatbot_duyen_leads', lead.id, lead, initialLeads),

  getZaloOAs: async (): Promise<ZaloOAConfig[]> => dataStore.getDocuments<ZaloOAConfig>('zalo_oa_configurations', initialZaloOAs),
  saveZaloOA: async (oa: ZaloOAConfig): Promise<ZaloOAConfig> => dataStore.saveDocument<ZaloOAConfig>('zalo_oa_configurations', oa.id, oa, initialZaloOAs),
  deleteZaloOA: async (id: string): Promise<boolean> => dataStore.deleteDocument<ZaloOAConfig>('zalo_oa_configurations', id, initialZaloOAs),

  getZaloMessages: async (): Promise<ZaloWebhookMessage[]> => {
    try {
      const res = await fetch('/api/zalo/messages');
      const data = await res.json();
      if (data.success) {
        setLocalCache('zalo_webhook_messages', data.list);
        return data.list;
      }
    } catch {}
    return getLocalCache<ZaloWebhookMessage[]>('zalo_webhook_messages', []);
  },

  getNotifications: async (): Promise<Notification[]> => dataStore.getDocuments<Notification>('notifications', initialNotifications),
  saveNotification: async (notif: Notification): Promise<Notification> => dataStore.saveDocument<Notification>('notifications', notif.id, notif, initialNotifications),

  // 3. CHAT HISTORY STORE
  getChatHistory: async (userId: string): Promise<any[]> => {
    try {
      const response = await databases.listDocuments(DATABASE_ID, 'chat_history', [
        Query.equal('userId', userId)
      ]);
      const fetched = response.documents.map(d => ({ id: d.$id, ...d })) as any[];
      fetched.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      setLocalCache(`chat_history_${userId}`, fetched);
      return fetched;
    } catch {
      const localHistory = getLocalCache<any[]>(`chat_history_${userId}`, []) as any[];
      localHistory.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      return localHistory;
    }
  },

  saveChatMessage: async (userId: string, sender: 'user' | 'assistant', text: string): Promise<any> => {
    const msgObj = {
      id: Math.random().toString(36).substring(7),
      userId,
      sender,
      text,
      timestamp: new Date().toISOString()
    };
    const key = `chat_history_${userId}`;
    const localHistory = getLocalCache<any[]>(key, []);
    localHistory.push(msgObj);
    setLocalCache(key, localHistory);

    try {
      return await databases.createDocument(DATABASE_ID, 'chat_history', msgObj.id, msgObj);
    } catch {
      return msgObj;
    }
  },

  // Diagnostics check connection
  testFirestoreConnection: async (): Promise<{ success: boolean; message: string; latencyMs?: number }> => {
    const startTime = Date.now();
    try {
      // Always call the real Appwrite listing function to check if server is reachable (even if previously flagged offline)
      await withTimeout(databases.listDocuments(DATABASE_ID, 'tasks', [Query.limit(1)]), 1500);
      const latency = Date.now() - startTime;
      
      const wasOffline = !isOnline;
      isOnline = true;
      try {
        sessionStorage.removeItem('tindan_appwrite_offline');
      } catch {}

      if (wasOffline) {
        console.info('[dataStore] Mạng ổn định trở lại! Tự động khôi phục chế độ Online-Sync thầm lặng.');
        syncCachedDataToCloud().catch(() => {});
      }

      return {
        success: true,
        message: 'Đã kết nối Appwrite Cloud. Toàn bộ cơ sở dữ liệu CRM Tín Dân sẵn sàng.',
        latencyMs: latency
      };
    } catch (e: any) {
      const errMsg = e?.message || '';
      const isNetworkError = 
        errMsg.includes('Failed to fetch') || 
        errMsg.includes('fetch') || 
        errMsg.includes('Network Error') || 
        errMsg.includes('timeout') ||
        e.name === 'TypeError' ||
        e.message?.includes('Connection timeout');

      if (isNetworkError) {
        setOfflineMode();
        return {
          success: false,
          message: 'Đang chạy chế độ Offline-First (LocalStorage Backup localDB). Tốc độ tối ưu.'
        };
      } else {
        // Auth error, 404 collection, or 403 means server is alive and fully reachable
        const latency = Date.now() - startTime;
        const wasOffline = !isOnline;
        isOnline = true;
        try {
          sessionStorage.removeItem('tindan_appwrite_offline');
        } catch {}

        if (wasOffline) {
          console.info('[dataStore] Tự động khôi phục chế độ Online-Sync thầm lặng (Xác thực thành công).');
          syncCachedDataToCloud().catch(() => {});
        }

        return {
          success: true,
          message: `Đã kết nối Appwrite Cloud. Toàn bộ cơ sở dữ liệu CRM sẵn sàng (${e.code || 'Active'}).`,
          latencyMs: latency
        };
      }
    }
  }
};

// Complete DB wrapper for modular components
export const DB = {
  ...dataStore,

  // User methods
  saveUser: async (user: User): Promise<User> => {
    return dataStore.saveDocument<User>('users', user.id, user, initialUsers);
  },
  updateUser: async (userId: string, fields: Partial<User>): Promise<User> => {
    const users = await dataStore.getUsers();
    const user = users.find(u => u.id === userId);
    const updated = { ...user, ...fields, id: userId } as User;
    return dataStore.saveDocument<User>('users', userId, updated, initialUsers);
  },
  deleteUser: async (userId: string): Promise<boolean> => {
    return dataStore.deleteDocument<User>('users', userId, initialUsers);
  },
  subscribeToUsers: (onUpdate: (users: User[]) => void): (() => void) => {
    return dataStore.subscribeToCollection('users', onUpdate, initialUsers);
  },
  getCachedUsers: (): User[] => {
    return getLocalCache<User[]>('users', initialUsers);
  },
  getCurrentUser: (): User | null => {
    return getLocalCache<User | null>('current_user', initialUsers[0]);
  },
  setCurrentUser: (user: User | null): void => {
    setLocalCache('current_user', user);
  },
  clearSystemCache: (): void => {
    try {
      const keys = Object.keys(localStorage);
      keys.forEach(k => {
        if (k.startsWith('tindan_')) {
          localStorage.removeItem(k);
        }
      });
      sessionStorage.removeItem('tindan_appwrite_offline');
      window.location.reload();
    } catch {}
  },

  // Project methods
  saveProjects: async (projects: Project[]): Promise<void> => {
    setLocalCache('projects', projects);
    for (const proj of projects) {
      await dataStore.saveProject(proj);
    }
  },
  deleteProject: async (id: string): Promise<boolean> => {
    return dataStore.deleteDocument<Project>('projects', id, initialProjects);
  },

  // Task methods
  saveTasks: async (tasks: Task[]): Promise<void> => {
    setLocalCache('tasks', tasks);
    for (const task of tasks) {
      await dataStore.saveTask(task);
    }
  },

  // Activity logs
  getActivityLogs: async (): Promise<any[]> => {
    return getLocalCache<any[]>('activity_logs', [
      { id: 'log_init', action: 'Hệ thống khởi chạy thành công', performedBy: 'Hệ thống', timestamp: new Date().toISOString() }
    ]);
  },
  saveActivityLogs: async (logs: any[]): Promise<void> => {
    setLocalCache('activity_logs', logs);
  },
  saveActivityLog: async (log: any): Promise<void> => {
    const logs = await DB.getActivityLogs();
    logs.unshift(log);
    setLocalCache('activity_logs', logs);
  },

  // Daily summaries
  getDailySummaries: async (): Promise<any[]> => {
    return getLocalCache<any[]>('daily_summaries', []);
  },
  saveDailySummaries: async (summaries: any[]): Promise<void> => {
    setLocalCache('daily_summaries', summaries);
  },

  // Task analyses
  getTaskAnalyses: async (): Promise<any[]> => {
    return getLocalCache<any[]>('task_analyses', []);
  },
  saveTaskAnalyses: async (analyses: any[]): Promise<void> => {
    setLocalCache('task_analyses', analyses);
  },

  // Task Risk Scores
  getTaskRiskScores: async (): Promise<TaskRiskScore[]> => {
    return dataStore.getRiskScores();
  },
  saveTaskRiskScores: async (scores: TaskRiskScore[]): Promise<void> => {
    setLocalCache('task_risk', scores);
    for (const score of scores) {
      await dataStore.saveDocument<TaskRiskScore>('task_risk', score.id, score, initialRisks);
    }
  },

  // Duyen Config
  getDuyenConfig: async (): Promise<any> => {
    const defaultConf = {
      oaName: 'Vivian Decal',
      isActive: true,
      autoReply: true,
      welcomeText: 'Chào mừng quý khách đến với Vivian Decal. Em là Mỹ Duyên, trợ lý AI tư vấn in sấy UV tem nhãn!',
      personality: 'Thân thiện, chuyên nghiệp, hỗ trợ thực tế'
    };
    return getLocalCache<any>('duyen_config', defaultConf);
  },
  saveDuyenConfig: async (config: any): Promise<void> => {
    setLocalCache('duyen_config', config);
  },

  // Duyen Leads
  getDuyenLeads: async (): Promise<Lead[]> => {
    return dataStore.getLeads();
  },
  saveDuyenLead: async (lead: Lead): Promise<Lead> => {
    return dataStore.saveLead(lead);
  },

  // Notifications
  saveNotifications: async (notifs: Notification[]): Promise<void> => {
    setLocalCache('notifications', notifs);
  },

  // Chat History helper for AIAssistant.tsx
  saveChatHistory: async (userId: string, messages: any[]): Promise<void> => {
    setLocalCache(`chat_history_${userId}`, messages);
    if (messages.length > 0) {
      const last = messages[messages.length - 1];
      await dataStore.saveChatMessage(userId, last.sender === 'user' ? 'user' : 'assistant', last.text || last.content || '');
    }
  },

  // Extra Mock Logs needed for Dashboard
  getAiKpiLogs: async (): Promise<any[]> => {
    return getLocalCache<any[]>('ai_kpi_logs', []);
  },
  getEmployeeWorkloads: async (): Promise<EmployeeWorkload[]> => {
    return dataStore.getWorkloads();
  }
};
