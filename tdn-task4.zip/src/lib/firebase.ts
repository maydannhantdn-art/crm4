// Harmless Firebase Compatibility Stub to prevent TypeScript build failures 
// during migration to Appwrite. All active clients have been redirected.

export const db: any = {};
export const auth: any = {};

export const ensureAuth = async () => {
  // No-op
  return true;
};
