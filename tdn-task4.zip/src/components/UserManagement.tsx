/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, UserRole, Department } from '../types';
import { DB } from '../lib/dataStore';
import { 
  Users, 
  UserPlus, 
  Shield, 
  Building2, 
  Trash2, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  XCircle,
  MoreVertical,
  Mail,
  User as UserIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function UserManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [newUser, setNewUser] = useState<Partial<User>>({
    role: UserRole.EMPLOYEE,
    department: Department.MARKETING,
    status: 'active',
    password: '',
    permissions: ['dashboard', 'tasks', 'assistant'] // Default basic permissions
  });

  const modules = [
    { id: 'dashboard', name: 'Bảng điều khiển', icon: <Users className="w-3 h-3" /> },
    { id: 'tasks', name: 'Công việc', icon: <CheckCircle2 className="w-3 h-3" /> },
    { id: 'kpis', name: 'Quản trị KPI', icon: <Shield className="w-3 h-3" /> },
    { id: 'projects', name: 'Dự án', icon: <Building2 className="w-3 h-3" /> },
    { id: 'assistant', name: 'Trợ lý AI', icon: <Shield className="w-3 h-3 text-blue-500" /> },
    { id: 'files', name: 'Kho dữ liệu', icon: <MoreVertical className="w-3 h-3" /> },
    { id: 'users', name: 'Quản trị Nhân sự', icon: <Users className="w-3 h-3" /> },
    { id: 'reports', name: 'Báo cáo thông minh', icon: <MoreVertical className="w-3 h-3" /> },
    { id: 'settings', name: 'Cài đặt hệ thống', icon: <Lock className="w-3 h-3" /> }
  ];

  const handleTogglePermission = (perms: string[] | undefined, moduleId: string) => {
    const list = perms || [];
    if (list.includes(moduleId)) {
      return list.filter(id => id !== moduleId);
    }
    return [...list, moduleId];
  };

  const loadUsersList = async () => {
    setIsLoading(true);
    try {
      const freshUsers = await DB.getUsers();
      setUsers(freshUsers);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsersList();
    const unsubscribe = DB.subscribeToUsers((freshUsers) => {
      if (freshUsers && freshUsers.length > 0) {
        setUsers(freshUsers);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.email || !newUser.name) return;

    const user: User = {
      id: 'u_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9),
      email: newUser.email,
      name: newUser.name,
      password: newUser.password || '123',
      role: newUser.role as UserRole,
      department: newUser.department as Department,
      status: 'active',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newUser.name}`,
      permissions: newUser.permissions || ['dashboard', 'tasks', 'assistant']
    };

    await DB.saveUser(user);
    setShowAddModal(false);
    setNewUser({ role: UserRole.EMPLOYEE, department: Department.MARKETING, status: 'active', password: '' });
    await loadUsersList();
  };

  const handleUpdateUserDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    await DB.updateUser(editingUser.id, {
      name: editingUser.name,
      role: editingUser.role,
      department: editingUser.department,
      password: editingUser.password,
      permissions: editingUser.permissions
    });
    setEditingUser(null);
    await loadUsersList();
  };

  const toggleUserStatus = async (user: User) => {
    const updated: User = { ...user, status: user.status === 'active' ? 'locked' : 'active' };
    await DB.saveUser(updated);
    await loadUsersList();
  };

  const handleDeleteUser = async (user: User) => {
    const activeSession = DB.getCurrentUser();
    if (user.email === 'tindancompany22@gmail.com') {
      alert('Tài khoản Super Admin gốc tindancompany22@gmail.com của Sếp không được phép xóa để đảm bảo an toàn truy cập.');
      return;
    }
    if (activeSession && user.id === activeSession.id) {
      alert('Sếp không thể tự xóa tài khoản của chính mình đang đăng nhập.');
      return;
    }
    if (window.confirm(`Sếp có chắc chắn muốn xóa tài khoản "${user.name}" (${user.role})? Toàn bộ phân quyền xưởng liên quan sẽ bị loại bỏ!`)) {
      await DB.deleteUser(user.id);
      await loadUsersList();
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-display text-slate-800 dark:text-white flex items-center gap-2 uppercase tracking-tight">
            <Users className="w-6 h-6 text-blue-600" />
            Quản trị Nhân sự & Phân quyền
          </h1>
          <p className="text-xs text-slate-400 mt-1">Cấp quyền truy cập, khóa tài khoản và điều chuyển phòng ban xưởng Tem Vivian</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-semibold shadow-lg shadow-blue-500/20 transition-all cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          Thêm thành viên mới
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="w-8 h-8 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
          <span className="text-xs text-slate-400 font-mono">Đang truy xuất tệp thông tin Tín Dân...</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {Array.from(new Map(users.map(u => [u.id, u])).values()).map((user) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                key={user.id}
                className={`glass-card p-5 relative group overflow-hidden border-l-4 ${user.status === 'active' ? 'border-emerald-500' : 'border-rose-500'}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <img 
                      src={user.avatar} 
                      alt={user.name} 
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-800"
                    />
                    <div>
                      <h3 className="text-sm font-bold text-slate-800 dark:text-white line-clamp-1">{user.name}</h3>
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-0.5">
                        <Mail className="w-3 h-3" />
                        <span className="truncate">{user.email}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => setEditingUser(user)}
                      className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-500/10 rounded-lg transition-colors border-none cursor-pointer"
                      title="Sửa phân quyền"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => toggleUserStatus(user)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        user.status === 'active' 
                          ? 'text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-500/10' 
                          : 'text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10'
                      }`}
                      title={user.status === 'active' ? "Khóa tài khoản" : "Mở khóa tài khoản"}
                    >
                      {user.status === 'active' ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                    </button>
                    <button 
                      onClick={() => handleDeleteUser(user)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                      title="Xóa tài khoản"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-3">
                  <div className="bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-widest">Quyền hạn</span>
                    <div className="flex items-center gap-1.5 mt-1">
                      <Shield className="w-3 h-3 text-blue-500" />
                      <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200">{user.role}</span>
                    </div>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-widest">Phòng ban</span>
                    <div className="flex items-center gap-1.5 mt-1">
                      <Building2 className="w-3 h-3 text-indigo-500" />
                      <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200">{user.department}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between text-[10px]">
                  <div className="flex items-center gap-1.5">
                    {user.status === 'active' ? (
                      <span className="flex items-center gap-1 text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-0.5 rounded-full font-bold">
                        <CheckCircle2 className="w-3 h-3" /> Hoạt động
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-rose-600 bg-rose-50 dark:bg-rose-500/10 px-2 py-0.5 rounded-full font-bold">
                        <XCircle className="w-3 h-3" /> Khoá truy cập
                      </span>
                    )}
                  </div>
                  <span className="text-slate-400 font-mono">ID: {user.id.slice(-6)}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Add User Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-card w-full max-w-md p-6 rounded-2xl shadow-2xl relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-bold font-display text-slate-800 dark:text-white uppercase tracking-tight">Thêm Thành viên Xưởng</h2>
                <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateUser} className="space-y-4 font-sans">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Tên nhân viên</label>
                  <input
                    type="text"
                    required
                    value={newUser.name || ''}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                    placeholder="Ví dụ: Trần Minh Đức"
                  />
                </div>
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Email truy cập</label>
                  <input
                    type="email"
                    required
                    value={newUser.email || ''}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                    placeholder="nhanvien@tindan.vn"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Mật khẩu khởi tạo</label>
                  <div className="relative">
                    <Lock className="w-3.5 h-3.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={newUser.password || ''}
                      onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                      className="w-full glass-input pl-10 pr-4 py-2.5 rounded-xl text-sm"
                      placeholder="TDN@..."
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Chức danh</label>
                    <select
                      value={newUser.role}
                      onChange={(e) => setNewUser({ ...newUser, role: e.target.value as UserRole })}
                      className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                    >
                      {Object.values(UserRole).map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Phòng ban</label>
                    <select
                      value={newUser.department}
                      onChange={(e) => setNewUser({ ...newUser, department: e.target.value as Department })}
                      className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                    >
                      {Object.values(Department).map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1 block">Quyền truy cập Module</label>
                  <div className="grid grid-cols-2 gap-2 bg-slate-50 dark:bg-slate-900/50 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                    {modules.map(mod => (
                      <label key={mod.id} className="flex items-center gap-2 cursor-pointer group">
                        <input 
                          type="checkbox"
                          checked={(newUser.permissions || []).includes(mod.id)}
                          onChange={() => setNewUser({ ...newUser, permissions: handleTogglePermission(newUser.permissions, mod.id) })}
                          className="w-3.5 h-3.5 rounded border-slate-300 text-blue-600 focus:ring-none"
                        />
                        <span className="text-[10px] text-slate-600 dark:text-slate-400 group-hover:text-blue-500 transition-colors uppercase font-medium">{mod.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-lg mt-4 transition-all uppercase tracking-widest text-[10px]"
                >
                  Xác nhận Gia nhập Tín Dân
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit User Modal */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-card w-full max-w-md p-6 rounded-2xl shadow-2xl relative"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-bold font-display text-slate-800 dark:text-white uppercase tracking-tight">Chỉnh sửa Nhân viên</h2>
                <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateUserDetails} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Tên hiển thị</label>
                  <input
                    type="text"
                    required
                    value={editingUser.name}
                    onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                    className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Đổi mật khẩu</label>
                  <div className="relative">
                    <Lock className="w-3.5 h-3.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={editingUser.password || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, password: e.target.value })}
                      className="w-full glass-input pl-10 pr-4 py-2.5 rounded-xl text-sm"
                      placeholder="Mật khẩu mới..."
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Quyền hạn</label>
                    <select
                      value={editingUser.role}
                      onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value as UserRole })}
                      className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                    >
                      {Object.values(UserRole).map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Phòng ban</label>
                    <select
                      value={editingUser.department}
                      onChange={(e) => setEditingUser({ ...editingUser, department: e.target.value as Department })}
                      className="w-full glass-input px-4 py-2.5 rounded-xl text-sm"
                    >
                      {Object.values(Department).map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase ml-1 block">Quyền truy cập Module</label>
                  <div className="grid grid-cols-2 gap-2.5 bg-slate-50 dark:bg-slate-900/50 p-4 rounded-2xl border border-slate-150 dark:border-slate-800">
                    {modules.map(mod => (
                      <label key={mod.id} className="flex items-center gap-2 cursor-pointer group">
                        <input 
                          type="checkbox"
                          checked={(editingUser.permissions || []).includes(mod.id)}
                          onChange={() => setEditingUser({ ...editingUser, permissions: handleTogglePermission(editingUser.permissions, mod.id) })}
                          className="w-4 h-4 rounded border-slate-300 text-blue-600 shadow-sm"
                        />
                        <span className="text-[11px] text-slate-600 dark:text-slate-400 group-hover:text-indigo-500 transition-colors font-semibold">{mod.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg mt-4 uppercase tracking-widest text-[10px]"
                >
                  Cập nhật thông tin
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
