import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Bot, Zap, Users, Layers, Terminal, Bell, 
  Clock, RefreshCw, Send, ShieldAlert,
  UserCheck, Award, Mail, FolderKanban, Workflow, FileText, 
  Settings as SettingsIcon, Brain, AlertTriangle, 
  ShieldCheck, Image, Search, Lock, LogOut
} from 'lucide-react';
import { dataStore } from './lib/dataStore';
import { Task, Project, KPIs, User, Lead, ZaloWebhookMessage, Notification } from './types';
import { ResponsiveContainer, XAxis, YAxis, Tooltip, AreaChart, Area } from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import Tasks from './components/Tasks';
import ProjectManager from './components/ProjectManager';
import ChatbotDuyen from './components/ChatbotDuyen';
import KPIManager from './components/KPIManager';
import UserManagement from './components/UserManagement';

const themeStyles = {
  midnight: {
    rootBg: 'bg-[#0b0f19]',
    sidebarBg: 'bg-[#090d16]',
    cardHighlight: 'border-blue-550/20 bg-blue-500/5',
    accentText: 'text-blue-450',
    accentBorder: 'border-blue-500/20',
    accentBtn: 'bg-blue-600 hover:bg-blue-700 text-white'
  },
  emerald: {
    rootBg: 'bg-[#05140f]',
    sidebarBg: 'bg-[#030a08]',
    cardHighlight: 'border-emerald-550/20 bg-emerald-500/5',
    accentText: 'text-emerald-450',
    accentBorder: 'border-emerald-500/20',
    accentBtn: 'bg-emerald-600 hover:bg-emerald-700 text-white'
  },
  violet: {
    rootBg: 'bg-[#0d091a]',
    sidebarBg: 'bg-[#070510]',
    cardHighlight: 'border-violet-550/20 bg-violet-500/5',
    accentText: 'text-violet-450',
    accentBorder: 'border-violet-500/20',
    accentBtn: 'bg-violet-600 hover:bg-violet-700 text-white'
  },
  solarized: {
    rootBg: 'bg-[#181510]',
    sidebarBg: 'bg-[#100e0a]',
    cardHighlight: 'border-amber-550/20 bg-amber-500/5',
    accentText: 'text-amber-450',
    accentBorder: 'border-amber-500/20',
    accentBtn: 'bg-amber-600 hover:bg-amber-700 text-white'
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'workspace' | 'inbox' | 'tasks' | 'projects' | 'teams' | 'crm' | 'ai-command' | 'knowledge' | 'kpis' | 'automation' | 'notifications' | 'files' | 'settings' | 'chatbot-duyen'
  >('workspace');

  const [themeColor, setThemeColor] = useState<'midnight' | 'emerald' | 'violet' | 'solarized'>(() => {
    return (localStorage.getItem('tdn_theme_color') as any) || 'midnight';
  });
  
  // Interactive User Session State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const cached = localStorage.getItem('tindan_current_user');
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  });

  // Login Form States
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Password reset inline states
  const [editingUserPasswordId, setEditingUserPasswordId] = useState<string | null>(null);
  const [editingUserPasswordValue, setEditingUserPasswordValue] = useState('');

  // Enterprise App Data States
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [kpis, setKPIs] = useState<KPIs[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [zaloMsgs, setZaloMsgs] = useState<ZaloWebhookMessage[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<{ success: boolean; message: string; latencyMs?: number }>({
    success: false,
    message: 'Đang kết nối hệ thống...'
  });

  // System States
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [currentNotification, setCurrentNotification] = useState<Notification | null>(null);

  // Forms & Interactive UI states
  const [showEmployeeForm, setShowEmployeeForm] = useState(false);
  const [newEmployeeName, setNewEmployeeName] = useState('');
  const [newEmployeeEmail, setNewEmployeeEmail] = useState('');
  const [newEmployeeRole, setNewEmployeeRole] = useState('Chuyên viên CRO');
  const [newEmployeeAvatar, setNewEmployeeAvatar] = useState('');
  const [newEmployeePassword, setNewEmployeePassword] = useState('123');

  // Interactive UI Simulation States
  const [inboxEmails, setInboxEmails] = useState([
    { id: '1', sender: 'Sếp Trần Tuấn Anh', title: 'Phê duyệt gấp phương án bypass 5001', snippet: 'Anh đã kiểm tra payload ngrok, đường truyền ổn định nhưng cần tối ưu...', content: 'Chào Đạt và đội ngũ phát triển, anh đã chạy thử nghiệm cổng post bypass qua localhost:5001 của anh. Phản hồi thô trả về ok tuy nhiên nếu ngrok bị sập, phải lập tức kích hoạt offline localDB dự phòng để không mất thông tin. Tiến hành ngay nhé!', time: '10:30 AM', read: false },
    { id: '2', sender: 'Lê Thị Mỹ Duyên (AI Helper)', title: '[IMPORTANT] Phát hiện Lead CRO chất lượng cao', snippet: 'Khách hàng Hoàng Gia Bảo đang yêu cầu báo giá trọn gói phễu...', content: 'Dạ sếp, chatbot em vừa bóc tách tự động một lead mới có điểm số intention đạt 5 sao. Khách hàng sử dụng SĐT 0912345678, đang vận hành chuỗi phân phối mỹ phẩm và muốn liên hệ trực tiếp sếp Trần Tuấn Anh để tư vấn sâu về phễu Zalo OA. Em đã đẩy thẳng vào mục phễu CRM rồi ạ!', time: '09:12 AM', read: true },
    { id: '3', sender: 'Zalo Webhook Monitor', title: 'Cảnh báo gia hạn Token Official Account', snippet: 'Token kết nối Zalo OA chỉ còn hiệu lực 12 ngày...', content: 'Hệ thống tự động phát hiện mã truy cập Access Token của OA Tín Dân Company chuẩn bị hết hạn. Vui lòng bấm vào Cấu hình Settings -> Refresh Token để cập nhật khóa bí mật.', time: 'Hôm qua', read: true }
  ]);
  const [activeEmail, setActiveEmail] = useState<string>('1');
  const [emailReplyText, setEmailReplyText] = useState('');

  const [chatbotText, setChatbotText] = useState('');
  const [chatbotConversation, setChatbotConversation] = useState<{ sender: 'user' | 'assistant', text: string, time: string }[]>([
    { sender: 'assistant', text: 'Dạ sếp! Em là Mỹ Duyên AI, trợ lý ảo thuộc Tín Dân Company. Em đã sẵn sàng tối ưu CRO và phân phối phễu Zalo CRM hôm nay!', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
  ]);
  const [chatbotLoading, setChatbotLoading] = useState(false);

  const [bypassCommand, setBypassCommand] = useState('');
  const [bypassConsole, setBypassConsole] = useState<{ type: 'input' | 'output' | 'error', text: string, time: string }[]>([
    { type: 'output', text: 'Hệ thống [SYSTEM_BYPASS] sẵn sàng. Đầu ra được forward thẳng về máy sếp Tuấn Anh...', time: new Date().toLocaleTimeString() }
  ]);
  const [customNgrok, setCustomNgrok] = useState('');

  // AI Knowledge Wiki Items
  const [knowledgeBase] = useState([
    { title: 'Tài liệu Giao thức Bypass 5001', category: 'Infrastructure', author: 'Sếp Trần Tuấn Anh', summary: 'Định nghĩa giải pháp routing an toàn, vượt qua các rào chắn proxy của iframe. Sử dụng port 5001 kết hợp ngrok proxy để phản hồi thô về máy cục bộ.', tags: ['Bypass', 'Command', 'Sếp'] },
    { title: 'Cẩm nang Tối ưu CRO Landing Page', category: 'Conversion Marketing', author: 'Phạm Hồng Nam', summary: 'Phân tích các hành vi nút bấm, tối ưu hóa text-spacing, rút gọn trường nhập số điện thoại để nâng ROI chuyển đổi tăng thêm 15%.', tags: ['CRO', 'Tín Dân UI'] },
    { title: 'Hướng dẫn cấu hình Webhook Zalo OA', category: 'Integration', author: 'Nguyễn Văn Đạt', summary: 'Biểu mẫu cấu hình API nhận tin nhắn từ người dùng, lọc dữ liệu rác, bóc tách bằng mô hình trí tuệ nhân tạo Gemini 2.5.', tags: ['Zalo', 'Webhook', 'API'] }
  ]);
  const [searchDocQuery, setSearchDocQuery] = useState('');

  // AI Memory Facts Registry
  const [aiMemories] = useState([
    { id: 'm1', content: 'Sếp Trần Tuấn Anh hay tiến hành bypass lệnh lúc tối muộn', category: 'Hành vi', reliability: '98%' },
    { id: 'm2', content: 'Ưu tiên tỷ lệ CRO trên 40% cho tất cả phễu Landing Page', category: 'Chiến thuật', reliability: '95%' },
    { id: 'm3', content: 'Chatbot Mỹ Duyên AI cần dùng giọng điệu ấm áp sếp quy định', category: 'Thương hiệu', reliability: '100%' },
    { id: 'm4', content: 'Khách hàng Hoàng Gia Bảo thích liên lạc trực tiếp hotline', category: 'Khách hàng', reliability: '90%' }
  ]);

  // Lead stages edit state
  const [focusedLead, setFocusedLead] = useState<Lead | null>(null);

  // Workflow Automation Rules
  const [automationRules, setAutomationRules] = useState([
    { id: 'a1', trigger: 'Khi có Lead Hotline mới từ Zalo OA', action: 'Gửi tin nhắn chào mừng + Báo tin sếp Trần Tuấn Anh', active: true },
    { id: 'a2', trigger: 'CRO của chiến dịch Landing Page giảm dưới 38%', action: 'Báo lỗi hệ thống + Tự động gửi cảnh báo cho Nam', active: true },
    { id: 'a3', trigger: 'Lệnh Bypass thô được gửi từ CMD', action: 'Ghi nhật ký Audit Log + Forward ngrok port 5001', active: false }
  ]);
  const [newRuleTrigger, setNewRuleTrigger] = useState('');
  const [newRuleAction, setNewRuleAction] = useState('');

  // File explorer documents
  const [fileVault] = useState([
    { name: 'BaoCaoDoanhThu_CRO_Q2.xlsx', type: 'excel', size: '2.4 MB', tag: 'KPIs', aiSummary: 'Bảng theo dõi ROI các chiến dịch phễu CRO tuần 1-12. Thể hiện tăng trưởng 8.4% so với quý 1.' },
    { name: 'GiaoThucBypass_DocServer.pdf', type: 'pdf', size: '1.8 MB', tag: 'Technical', aiSummary: 'Tài liệu hướng dẫn cài đặt proxy server Llama 3 cục bộ dưới máy sếp Trần Tuấn Anh.' },
    { name: 'AnhGiaoDienV1_LoiDesign.png', type: 'image', size: '4.2 MB', tag: 'Design', aiSummary: 'Ảnh chụp màn hình lỗi lệch typography ở thanh cuộn di động của Landing Page.' }
  ]);

  // Load essential records
  const loadAllData = async () => {
    setSyncing(true);
    try {
      const ping = await dataStore.testFirestoreConnection();
      setConnectionStatus(ping);

      const tasksList = await dataStore.getTasks();
      const projectsList = await dataStore.getProjects();
      const kpiList = await dataStore.getKPIs();
      const usersList = await dataStore.getUsers();
      const leadsList = await dataStore.getLeads();
      const notificationList = await dataStore.getNotifications();
      const messageList = await dataStore.getZaloMessages();

      if (tasksList) setTasks(tasksList);
      if (projectsList) setProjects(projectsList);
      if (kpiList) setKPIs(kpiList);
      if (usersList) setUsers(usersList);
      if (leadsList) setLeads(leadsList);
      if (notificationList) setNotifications(notificationList);
      if (messageList) setZaloMsgs(messageList);
      
      // Auto-trigger alerts
      if (notificationList && notificationList.length > 0) {
        const unread = notificationList.find(n => !n.read);
        if (unread) setCurrentNotification(unread);
      }
    } catch (e) {
      console.warn('Fallback cache utilized for dataStore initialization.', e);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, [activeTab]);

  // Creation logic for personnel
  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmployeeName.trim() || !newEmployeeEmail.trim()) return;

    const newId = 'user_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    const avatarUrl = newEmployeeAvatar.trim() || `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 500000)}?auto=format&fit=crop&q=80&w=200`;
    
    const newWorker: User = {
      id: newId,
      name: newEmployeeName,
      email: newEmployeeEmail,
      role: newEmployeeRole,
      avatar: avatarUrl,
      password: newEmployeePassword.trim() || '123',
      permissions: ['workspace', 'tasks', 'knowledge', 'notifications', 'files'] // Default permissions for new staff
    };

    setUsers(prev => {
      const updated = [...prev, newWorker];
      return Array.from(new Map(updated.map(u => [u.id, u])).values());
    });
    setShowEmployeeForm(false);

    try {
      await dataStore.saveDocument<User>('users', newId, newWorker, users);
      
      const notif: Notification = {
        id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9),
        title: 'Thành viên mới gia nhập',
        message: `${newEmployeeName} (${newEmployeeRole}) vừa được kích hoạt trên hệ thống Workspace OS!`,
        type: 'success',
        read: false,
        timestamp: new Date().toISOString()
      };
      setNotifications(prev => {
        const updated = [notif, ...prev];
        return Array.from(new Map(updated.map(n => [n.id, n])).values());
      });
      await dataStore.saveNotification(notif);

      setNewEmployeeName('');
      setNewEmployeeEmail('');
      setNewEmployeeAvatar('');
    } catch (err) {
      console.error(err);
    }
  };

  // Interactive chatbot responses
  const handleChatbotSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatbotText.trim()) return;

    const userMsg = chatbotText;
    setChatbotConversation(prev => [...prev, { sender: 'user', text: userMsg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    setChatbotText('');
    setChatbotLoading(true);

    try {
      const res = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: 'boss_user', text: userMsg })
      });
      const data = await res.json();
      setChatbotConversation(prev => [...prev, { sender: 'assistant', text: data.reply, time: new Date(data.timestamp || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    } catch {
      setTimeout(() => {
        setChatbotConversation(prev => [...prev, { 
          sender: 'assistant', 
          text: `Dạ sếp! Em Mỹ Duyên AI ghi nhận câu hỏi thô: "${userMsg}". Em đã lưu thông tin và bóc tách dữ liệu CRO để xử lý lập tức ạ!`, 
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
        }]);
      }, 700);
    } finally {
      setChatbotLoading(false);
    }
  };

  // NGROK special bypass execution shell
  const handleExecuteBypass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bypassCommand.trim()) return;

    const cmd = bypassCommand;
    setBypassConsole(prev => [...prev, { type: 'input', text: cmd, time: new Date().toLocaleTimeString() }]);
    setBypassCommand('');

    try {
      const res = await fetch('/api/system/bypass', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd, ngrokUrl: customNgrok })
      });
      const data = await res.json();
      
      setBypassConsole(prev => [
        ...prev, 
        { type: 'output', text: data.message, time: new Date().toLocaleTimeString() }
      ]);
      if (data.result) {
        setBypassConsole(prev => [
          ...prev, 
          { type: 'output', text: JSON.stringify(data.result, null, 2), time: new Date().toLocaleTimeString() }
        ]);
      }
    } catch (err: any) {
      setBypassConsole(prev => [
        ...prev, 
        { type: 'error', text: `Bypass warning: Lệnh đã được chuyển tiếp nhưng chưa nhận tín hiệu phản hồi thực tế từ Port 5001. Thao tác thô: "${cmd}"`, time: new Date().toLocaleTimeString() }
      ]);
    }
  };

  // Add automation rule
  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleTrigger.trim() || !newRuleAction.trim()) return;
    setAutomationRules(prev => [...prev, { id: 'rule_' + Date.now(), trigger: newRuleTrigger, action: newRuleAction, active: true }]);
    setNewRuleTrigger('');
    setNewRuleAction('');
  };

  // Corporate Login System
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim()) return;
    
    const found = users.find(u => 
      u.email.toLowerCase().trim() === loginEmail.toLowerCase().trim() ||
      u.name.toLowerCase().trim() === loginEmail.toLowerCase().trim()
    );
    if (found) {
      const isPasswordValid = found.password ? found.password === loginPassword : (loginPassword === '123' || loginPassword === '123456');
      if (isPasswordValid) {
        const loggedUser = { ...found, password: found.password || (found.name === 'Admin' ? '123456' : '123') };
        setCurrentUser(loggedUser);
        localStorage.setItem('tindan_current_user', JSON.stringify(loggedUser));
        setLoginError('');

        // Trigger greeting success alert
        const notif: Notification = {
          id: 'notif_' + Date.now(),
          title: 'Đăng nhập thành công',
          message: `${loggedUser.name} (${loggedUser.role}) đã truy cập thành công hệ thống CRM.`,
          type: 'success',
          read: false,
          timestamp: new Date().toISOString()
        };
        setNotifications(prev => [notif, ...prev]);
        dataStore.saveNotification(notif).catch(() => {});
      } else {
        setLoginError('Mật khẩu không hợp lệ! Vui lòng kiểm tra và thử lại.');
      }
    } else {
      // Direct boss login fallback if user state hasn't loaded yet
      if ((loginEmail.toLowerCase().trim() === 'admin' || loginEmail === 'admin@tindan.com') && loginPassword === '123456') {
        const defaultBoss: User = {
          id: '1',
          name: 'Admin',
          email: 'admin@tindan.com',
          role: 'CEO / Quản lý tối cao',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
          password: '123456',
          permissions: ['workspace', 'inbox', 'tasks', 'projects', 'teams', 'crm', 'ai-command', 'knowledge', 'kpis', 'automation', 'notifications', 'files', 'settings']
        };
        setCurrentUser(defaultBoss);
        localStorage.setItem('tindan_current_user', JSON.stringify(defaultBoss));
        setLoginError('');
      } else {
        setLoginError('Tài khoản này chưa được đăng ký trong biên chế Tín Dân!');
      }
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('tindan_current_user');
    setLoginEmail('');
    setLoginPassword('');
    setLoginError('');
  };

  // Helper values
  const totalLeads = leads.length;
  const activeTasks = tasks.filter(t => t.status !== 'done').length;
  const pendingBypass = tasks.filter(t => t.status === 'backlog').length;

  // Real-time calculation helpers for the "Trực quan" (Workspace) dashboard
  const convertedLeads = leads.filter(l => l.status === 'interested' || l.status === 'closed').length;
  const croRateValue = leads.length > 0 ? ((convertedLeads / leads.length) * 105).toFixed(1) : '41.2';
  const actualCroRateValue = parseFloat(croRateValue) > 100 ? '100' : croRateValue;
  const avgKpiProgress = kpis.length > 0 
    ? Math.round(kpis.reduce((acc, curr) => acc + (Math.min(curr.current / curr.target, 1) * 100), 0) / kpis.length)
    : 0;

  const leadFunnelData = [
    { name: 'Tiếp nhận', count: leads.filter(l => l.status === 'new').length },
    { name: 'Liên hệ', count: leads.filter(l => l.status === 'contacted').length },
    { name: 'Quan tâm', count: leads.filter(l => l.status === 'interested').length },
    { name: 'Chốt đơn', count: leads.filter(l => l.status === 'closed').length }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0b0f19] flex items-center justify-center font-mono text-xs text-slate-400">
        <div className="space-y-4 text-center px-4">
          <Zap className="w-8 h-8 text-emerald-400 animate-bounce mx-auto" />
          <p className="text-emerald-400 font-bold uppercase tracking-widest text-[11px]">Nạp lõi hệ thống TDN AI Workspace OS v2...</p>
          <p className="text-slate-600 text-[10px]">Đang đồng bộ thực tế Appwrite Cloud & Local Cache...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#070a13] flex flex-col items-center justify-center font-sans px-4 select-none antialiased relative overflow-hidden">
        {/* Futuristic glowing spheres */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-60 h-60 bg-blue-500/5 rounded-full blur-[80px] pointer-events-none" />

        <div className="w-full max-w-sm bg-[#0c101d] border border-slate-800/80 rounded-2xl p-6.5 space-y-6 shadow-2xl relative z-10">
          
          {/* Header branding */}
          <div className="text-center space-y-2.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-blue-500 flex items-center justify-center shadow-lg shadow-emerald-500/20 mx-auto">
              <Zap className="w-6 h-6 text-slate-950 stroke-[2.2] animate-pulse" />
            </div>
            <div>
              <h1 className="font-display font-extrabold tracking-tight text-white text-base leading-tight uppercase">
                TDN Workspace OS
              </h1>
              <p className="text-[10px] text-emerald-400 font-mono tracking-widest uppercase font-semibold">
                CỔNG DOANH NGHIỆP TÍN DÂN
              </p>
            </div>
          </div>

          {/* Interactive error banner */}
          {loginError && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/15 text-rose-350 text-[11px] rounded-lg text-center font-medium flex items-center justify-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-450 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          {/* Manual Login Form */}
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-[9px] font-mono text-slate-400 mb-1 font-bold uppercase tracking-wider">Email tài khoản</label>
              <input
                type="email"
                required
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                placeholder="vd: dat.nguyen@tindan.com"
                className="w-full bg-[#121625] border border-slate-800/80 rounded-xl px-3.5 py-2.5 text-xs font-medium focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-650 text-white"
              />
            </div>
            <div>
              <label className="block text-[9px] font-mono text-slate-400 mb-1 font-bold uppercase tracking-wider">Mật khẩu bảo mật</label>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="Gõ hoặc chọn nhanh..."
                className="w-full bg-[#121625] border border-slate-800/80 rounded-xl px-3.5 py-2.5 text-xs font-medium focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-650 text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-500 text-slate-950 text-xs font-bold rounded-xl hover:bg-emerald-400 shadow-md shadow-emerald-500/15 transition-all text-center uppercase tracking-wider"
            >
              VÀO HỆ THỐNG
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div id="tdn-os-root" className={`min-h-screen flex flex-col md:flex-row ${themeStyles[themeColor].rootBg} text-slate-100 overflow-hidden font-sans select-none antialiased`}>
      
      {/* ========================================================================= */}
      {/* 1. LEFT SIDEBAR: OS NAVIGATION PANEL (13 TAB SELECTION)                  */}
      {/* ========================================================================= */}
      <aside id="left-sidebar" className={`w-full md:w-68 ${themeStyles[themeColor].sidebarBg} border-b md:border-b-0 md:border-r border-slate-800/60 flex flex-col justify-between shrink-0 h-screen overflow-y-auto`}>
        <div className="p-4.5 space-y-5">
          {/* TDN Enterprise Branding */}
          <div className="flex items-center space-x-3 pb-3 border-b border-slate-800/40">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-blue-500 flex items-center justify-center shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">
              <Zap className="w-5 h-5 text-slate-950 stroke-[2.2] animate-pulse" />
            </div>
            <div>
              <h2 className="font-display font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-emerald-400 text-sm leading-tight uppercase">
                TDN Workspace
              </h2>
              <span className="text-[10px] text-emerald-400 font-mono tracking-widest block font-bold">
                SYSTEM OS V2.0
              </span>
            </div>
          </div>

          {/* Connected Appwrite Indicator */}
          <div className="p-2.5 rounded-lg bg-emerald-500/5 border border-emerald-500/20 flex items-center justify-between shadow-inner">
            <div className="flex items-center space-x-2">
              <span className={`w-2 h-2 rounded-full ${connectionStatus.success ? 'bg-emerald-500 animate-ping' : 'bg-amber-500'}`} />
              <span className="text-[11px] font-mono text-slate-300 font-medium">
                {connectionStatus.success ? 'Appwrite Cloud' : 'Offline-First Cache'}
              </span>
            </div>
            {connectionStatus.latencyMs && (
              <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/10 px-1 py-0.2 rounded font-semibold">
                {connectionStatus.latencyMs}ms
              </span>
            )}
          </div>

          {/* Navigation Items */}
          <nav id="sidebar-navigation" className="space-y-0.5">
            <p className="text-[10px] font-mono text-slate-500 font-semibold tracking-wider px-2 uppercase mb-1">
              Hệ thống lõi
            </p>
            {[
              { id: 'workspace', label: 'Trực quan', icon: Layers, count: null },
              { id: 'tasks', label: 'Phân việc', icon: FolderKanban, count: activeTasks },
              { id: 'projects', label: 'Dự án', icon: Clock, count: projects.length },
              { id: 'teams', label: 'Phòng ban', icon: Users, count: users.length },
              { id: 'kpis', label: 'Bảng chỉ số KPI', icon: TrendingUp, count: null },
              { id: 'chatbot-duyen', label: 'Trợ lý Duyên AI', icon: Bot, count: null },
              { id: 'notifications', label: 'Thông báo', icon: Bell, count: notifications.filter(n => !n.read).length },
              { id: 'files', label: 'Kho lưu trữ', icon: Image, count: null },
              { id: 'settings', label: 'Cấu hình', icon: SettingsIcon, count: null }
            ].map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              // Verify tab permissions (everyone gets access to configured modules, admin is super)
              const permitted = true;
              
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full flex items-center justify-between px-3 py-1.8 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                    isActive 
                      ? 'bg-gradient-to-r from-emerald-500/15 to-emerald-500/5 text-emerald-300 border-l-[3px] border-emerald-500 shadow-md' 
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className={!permitted ? 'text-slate-500' : ''}>{item.label}</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    {!permitted && (
                      <Lock className="w-3 h-3 text-amber-500/70" />
                    )}
                    {item.count !== null && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                        isActive ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {item.count}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer info containing Tuấn Anh Sếp metadata */}
        <div className="p-4 border-t border-slate-800/40 bg-slate-900/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2.5 min-w-0">
              <div className="relative shrink-0">
                <img 
                  src={currentUser?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"} 
                  alt={currentUser?.name} 
                  referrerPolicy="no-referrer"
                  className="w-8.5 h-8.5 rounded-full border border-emerald-500/30 object-cover"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#090d16] rounded-full" />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-bold text-white leading-tight truncate">{currentUser?.name}</p>
                <p className="text-[9px] font-mono text-emerald-400 uppercase tracking-wider truncate">{currentUser?.id === '1' ? 'Tín Dân CEO' : 'Nhân viên'}</p>
              </div>
            </div>
            
            {/* Logout Switch Button */}
            <button
              onClick={handleLogout}
              title="Thoát khỏi hệ thống"
              className="p-1.5 bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-800 rounded-lg transition-all active:scale-95"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-3 text-[9px] font-mono text-slate-500 flex justify-between items-center bg-slate-950/20 p-1.5 rounded">
            <span>Core OS v2.0 - Active</span>
            <RefreshCw onClick={loadAllData} className={`w-3 h-3 text-emerald-400 cursor-pointer ${syncing ? 'animate-spin' : 'hover:scale-110'}`} />
          </div>
        </div>
      </aside>

      {/* ========================================================================= */}
      {/* 2. CENTER STAGE: DYNAMIC ENTERPRISE WORKSPACE SCREEN                      */}
      {/* ========================================================================= */}
      <main id="center-workspace-stage" className="flex-1 flex flex-col h-screen overflow-y-auto bg-gradient-to-b from-[#101625] via-[#0c101a] to-[#0a0c14] border-r border-slate-800/40 relative">
        
        {/* Dynamic Nav Header status */}
        <header className="h-14 bg-[#0a0e17]/80 backdrop-blur-md border-b border-slate-800/40 px-5 flex items-center justify-between shrink-0 sticky top-0 z-10">
          <div className="flex items-center space-x-3">
            <div className="capitalize text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/15">
              {activeTab}
            </div>
            <h1 className="text-sm font-display font-extrabold text-white tracking-tight uppercase">
              {activeTab === 'workspace' && 'Bảng Điều Khiển Trực Quan OS'}
              {activeTab === 'tasks' && 'Trung Tâm Quản Lý Việc Làm'}
              {activeTab === 'projects' && 'Lộ Trình Chiến Dịch Projects'}
              {activeTab === 'teams' && 'Cấu Trúc Phòng Ban Tín Dân'}
              {activeTab === 'kpis' && 'Biểu Đồ Chỉ Số KPIs Doanh Nghiệp'}
              {activeTab === 'chatbot-duyen' && 'Trợ Lý Doanh Nghiệp Mỹ Duyên AI'}
              {activeTab === 'notifications' && 'Thông Báo Hệ Thống & Cảnh Báo'}
              {activeTab === 'files' && 'Kho Lưu Trữ Classify Files'}
              {activeTab === 'settings' && 'Cài Đặt Cấu Hình OS'}
            </h1>
          </div>

          <div className="flex items-center space-x-3.5">
            <span className="hidden sm:inline-flex items-center space-x-1 px-2.5 py-1 bg-slate-900/50 border border-slate-800/60 rounded text-[10px] font-mono text-slate-400">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>Conversion Rate: <b className="text-emerald-400">41.2%</b></span>
            </span>
          </div>
        </header>

        {/* Action toast for global system events */}
        <AnimatePresence>
          {currentNotification && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-16 left-4 right-4 z-25 bg-[#0f1c2c] border border-blue-500/30 p-3 rounded-lg flex justify-between items-center shadow-lg"
            >
              <div className="flex items-center space-x-2.5">
                <AlertTriangle className="w-4 h-4 text-blue-400 animate-bounce" />
                <div className="text-xs">
                  <span className="font-bold text-white">{currentNotification.title}:</span>{' '}
                  <span className="text-slate-300">{currentNotification.message}</span>
                </div>
              </div>
              <button 
                onClick={() => setCurrentNotification(null)}
                className="text-slate-400 hover:text-white font-mono text-2xs bg-slate-800 px-1.5 py-0.5 rounded"
              >
                ĐÃ ĐỌC
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tab content renderer router */}
        <div className="p-5.5 flex-1 space-y-6">
          
          {(() => {
            const permitted = currentUser?.id === '1' || (currentUser?.permissions || ['workspace', 'tasks', 'knowledge', 'notifications', 'files']).includes(activeTab);
            if (!permitted) {
              return (
                <div className="flex flex-col items-center justify-center py-16 text-center select-none bg-slate-950/20 border border-rose-500/10 rounded-2xl p-8 space-y-5 shadow-2xl">
                  {/* Lock symbol */}
                  <div className="w-14 h-14 rounded-full bg-rose-500/10 flex items-center justify-center border border-rose-500/20 shadow-inner">
                    <Lock className="w-5 h-5 text-rose-500 animate-pulse" />
                  </div>
                  <div className="space-y-2 max-w-sm">
                    <h2 className="font-display font-extrabold text-white text-xs uppercase tracking-widest">
                      TRUY CẬP PHÂN HỆ BỊ KHÓA
                    </h2>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Xin chào <b className="text-slate-200">{currentUser?.name}</b>! Tài khoản nhân viên của bạn chưa được cấp thẩm quyền truy xuất trực tiếp phân hệ <code className="text-emerald-400 font-mono capitalize px-1 bg-slate-900 border border-slate-800 rounded">"{activeTab}"</code>.
                    </p>
                  </div>
                  
                  {/* Alert and button to ask boss */}
                  <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-2.5 max-w-xs w-full">
                    <p className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Thông điệp phê duyệt</p>
                    <button
                      onClick={() => {
                        const notif: Notification = {
                          id: 'notif_' + Date.now(),
                          title: 'Yêu cầu mở khóa phân hệ',
                          message: `Thành viên ${currentUser?.name} (${currentUser?.role}) vừa yêu cầu kích hoạt module "${activeTab}".`,
                          type: 'warning',
                          read: false,
                          timestamp: new Date().toISOString()
                        };
                        setNotifications(prev => [notif, ...prev]);
                        dataStore.saveNotification(notif).catch(() => {});
                        alert(`Gửi tín hiệu mở khẩn cấp phân hệ "${activeTab}" về Sảnh chờ thành công! Vui lòng đợi Sếp Trần Tuấn Anh mở khóa.`);
                      }}
                      className="w-full py-1.8 bg-emerald-500/10 hover:bg-emerald-500/15 border border-emerald-500/20 text-emerald-300 hover:text-emerald-250 text-2xs font-extrabold rounded-lg transition-all uppercase tracking-wider font-mono"
                    >
                      Báo sếp duyệt ngay
                    </button>
                  </div>
                </div>
              );
            }
            return null;
          })()}

          {/* Render normal content only if permitted */}
          {(currentUser?.id === '1' || (currentUser?.permissions || ['workspace', 'tasks', 'knowledge', 'notifications', 'files']).includes(activeTab)) && (
            <>
            {activeTab === 'workspace' && (
              <div className="space-y-6">
                {/* Core Analytics Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5">
                  {[
                    { title: 'Tỷ Lệ Đăng Ký CRO', value: `${actualCroRateValue}%`, detail: `${convertedLeads} Khách có nhu cầu`, icon: TrendingUp, color: 'text-emerald-400', bg: 'bg-emerald-500/5' },
                    { title: 'Tổng Khách Hàng', value: `${totalLeads} Leads`, detail: 'Đồng bộ hệ thống Zalo OA', icon: Bot, color: 'text-blue-400', bg: 'bg-blue-500/5' },
                    { title: 'Tiến độ KPI Trung bình', value: `${avgKpiProgress}%`, detail: `${kpis.length} Mục tiêu hoạt động xưởng`, icon: Award, color: 'text-amber-400', bg: 'bg-amber-500/5' }
                  ].map((card, i) => {
                    const Icon = card.icon;
                    return (
                      <div key={i} className="p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex items-center justify-between shadow-md">
                        <div>
                          <span className="text-[10px] font-mono text-slate-400 tracking-wider uppercase block">{card.title}</span>
                          <h4 className="text-xl font-display font-extrabold text-white mt-1.5">{card.value}</h4>
                          <span className="text-[10px] text-slate-500 font-mono mt-1 block">{card.detail}</span>
                        </div>
                        <div className={`w-11 h-11 rounded-xl ${card.bg} flex items-center justify-center border border-slate-700/20`}>
                          <Icon className={`w-5.5 h-5.5 ${card.color}`} />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Bento Row 1: Charts & Key Projects */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                  {/* Advanced Chart */}
                  <div className="lg:col-span-2 p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-display font-bold text-white text-xs">Cơ cấu Trực quan Phễu CRM Tín Dân</h3>
                          <p className="text-[10px] text-slate-400 mt-0.5">Vẽ tự động theo danh sách Leads thật trong cơ sở dữ liệu</p>
                        </div>
                        <span className="bg-emerald-500/10 text-emerald-400 text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border border-emerald-500/25">DỮ LIỆU THỰC</span>
                      </div>
                    </div>
                    <div className="h-[200px] mt-4.5">
                      <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                        <AreaChart data={leadFunnelData}>
                          <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                          <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                          <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', fontSize: '10px' }} />
                          <Area type="monotone" dataKey="count" stroke="#10b981" fillOpacity={0.1} fill="url(#colorLeadsCount)" name="Số lượng khách hàng" />
                          <defs>
                            <linearGradient id="colorLeadsCount" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>


                {/* KPI snap */}
                <div className="p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex flex-col justify-between">
                  <div>
                    <h3 className="font-display font-bold text-white text-xs uppercase tracking-wide">Chiến Dịch KPI Hiện Tại</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Định vị mục tiêu phễu</p>
                    <div className="space-y-4 mt-4">
                      {kpis.slice(0, 3).map(k => (
                        <div key={k.id} className="p-2.5 bg-slate-950/40 rounded-lg border border-slate-800/40">
                          <div className="flex justify-between items-center text-xs">
                            <span className="font-bold text-white">{k.name}</span>
                            <span className="font-mono text-emerald-400 font-bold">{((k.current / k.target) * 100).toFixed(0)}%</span>
                          </div>
                          <div className="w-full h-1.5 rounded-full bg-slate-800 mt-1.5 overflow-hidden">
                            <div className="h-full bg-emerald-500" style={{ width: `${Math.min((k.current / k.target) * 100, 100)}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent activity timeline */}
              <div className="p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md">
                <h3 className="font-display font-bold text-white text-xs uppercase tracking-wider mb-3.5">Hành Động Hoạt Động Gần Đây</h3>
                <div className="space-y-3.5">
                  <div className="p-3 bg-slate-950/35 rounded-lg border border-slate-800/30 flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                      <div>
                        <p className="text-xs font-semibold text-white">Lệnh Bypass thô nhận được phản hồi thô</p>
                        <p className="text-[10px] text-slate-400">Giao thức [SYSTEM_BYPASS] kích hoạt bởi Tuấn Anh</p>
                      </div>
                    </div>
                    <span className="text-[9px] font-mono text-slate-500">{new Date().toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: INBOX                                                            */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'inbox' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 h-[550px]">
              
              {/* Mail list panel */}
              <div className="bg-slate-900/30 border border-slate-800/80 rounded-xl overflow-y-auto p-3 space-y-2 h-full scrollbar">
                <p className="text-[10px] font-mono text-slate-500 uppercase font-semibold px-2">Hũ Thư Đã Nhận</p>
                {inboxEmails.map(e => (
                  <button 
                    key={e.id}
                    onClick={() => {
                      setActiveEmail(e.id);
                      setInboxEmails(prev => prev.map(item => item.id === e.id ? { ...item, read: true } : item));
                    }}
                    className={`w-full text-left p-3 rounded-lg border transition ${
                      activeEmail === e.id 
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-white' 
                        : 'bg-slate-900/20 border-slate-800/50 text-slate-300 hover:bg-slate-800/20'
                    }`}
                  >
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="font-bold text-slate-400">{e.sender}</span>
                      <span className="font-mono text-slate-500">{e.time}</span>
                    </div>
                    <h4 className="font-semibold text-xs mt-1 truncate">{e.title}</h4>
                    <p className="text-[10px] text-slate-400 mt-1 lines-clamp-1 truncate">{e.snippet}</p>
                    {!e.read && <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 mt-1.5" />}
                  </button>
                ))}
              </div>

              {/* Mail reading area */}
              <div className="md:col-span-2 bg-slate-900/40 border border-slate-800/80 backdrop-blur-md rounded-xl p-4 flex flex-col justify-between h-full">
                {(() => {
                  const currentMail = inboxEmails.find(x => x.id === activeEmail);
                  if (!currentMail) return <div className="text-slate-500 text-xs italic">Hãy chọn một email để hiển thị...</div>;
                  return (
                    <>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center pb-3 border-b border-slate-800/40">
                          <div>
                            <h3 className="font-bold text-white text-sm">{currentMail.title}</h3>
                            <p className="text-[10px] text-slate-400 mt-1">Từ: <span className="text-emerald-400 font-bold">{currentMail.sender}</span></p>
                          </div>
                          <span className="text-xs font-mono text-slate-500">{currentMail.time}</span>
                        </div>
                        <p className="text-xs text-slate-200 whitespace-pre-wrap leading-relaxed bg-slate-950/40 p-3 rounded-lg border border-slate-900">
                          {currentMail.content}
                        </p>
                      </div>

                      {/* Reply form */}
                      <div className="pt-4 border-t border-slate-800/40">
                        <div className="flex space-x-2">
                          <input 
                            type="text" 
                            value={emailReplyText}
                            onChange={(e) => setEmailReplyText(e.target.value)}
                            placeholder="Gửi phản hồi nhanh cho người nhận..."
                            className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs focus:outline-none focus:border-emerald-500"
                          />
                          <button 
                            onClick={() => {
                              if (!emailReplyText.trim()) return;
                              alert(`Đã gửi phản hồi thô: "${emailReplyText}"`);
                              setEmailReplyText('');
                            }}
                            className="px-4 py-1.5 bg-emerald-500 text-slate-950 rounded text-xs font-bold hover:bg-emerald-400 transition"
                          >
                            PHẢN HỒI
                          </button>
                        </div>
                        <p className="text-[9px] text-slate-500 mt-1.5 italic text-right font-mono">Powered by TDN Email Proxy Gateway</p>
                      </div>
                    </>
                  );
                })()}
              </div>

            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: TASKS                                                            */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'tasks' && (
            <Tasks 
              currentUser={currentUser!}
              users={users}
              projects={projects}
            />
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: PROJECTS                                                         */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'projects' && (
            <ProjectManager 
              currentUser={currentUser!}
              projects={projects}
              setProjects={setProjects}
            />
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: TEAMS (STAFF)                                                    */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'teams' && (
            <UserManagement />
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: CRM LEADS AND ZALO COAX                                          */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'crm' && (
            <div className="space-y-6">
              
              {/* Leads segment */}
              <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md">
                <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-800/40">
                  <div>
                    <h3 className="font-display font-extrabold text-white text-xs uppercase tracking-wider">Phễu Chăm Sóc Khách Hàng CRM</h3>
                    <p className="text-[10px] text-slate-400">Dữ liệu bóc tách thô tự động từ cuộc chuyện trò của Chatbot Duyên AI</p>
                  </div>
                  <UserCheck className="w-5 h-5 text-emerald-400" />
                </div>

                <div className="space-y-3">
                  {leads.map(l => (
                    <div 
                      key={l.id} 
                      onClick={() => setFocusedLead(l)}
                      className="p-3.5 bg-slate-950/45 border border-slate-800/80 hover:border-emerald-500/30 transition rounded-lg flex flex-col md:flex-row justify-between gap-4 cursor-pointer"
                    >
                      <div>
                        <div className="flex items-center space-x-2.5">
                          <span className="text-xs font-bold text-white">{l.name}</span>
                          <span className="text-[8px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">AI EXTRACTED</span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">{l.description}</p>
                        
                        <div className="flex flex-wrap gap-4 text-[9px] font-mono text-slate-500 mt-2.5">
                          <span>SĐT: <b className="text-slate-300">{l.phone || 'Chưa có'}</b></span>
                          <span>Email: <b className="text-slate-300">{l.email || 'Chưa gán'}</b></span>
                          <span>Độ tuổi: <b className="text-slate-300">{l.age || 'N/A'}</b></span>
                          <span>Địa điểm: <b className="text-slate-300">{l.address || 'Quốc tế'}</b></span>
                        </div>
                      </div>

                      <div className="text-right flex flex-col justify-between items-end">
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20 rounded text-[9px] font-mono uppercase">
                          {l.status}
                        </span>
                        <div className="flex space-x-0.5 text-amber-500 mt-2">
                          {Array.from({ length: l.rating || 3 }).map((_, i) => (
                            <Award key={i} className="w-3 h-3 fill-amber-500 stroke-none" />
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Focus detail logic */}
              {focusedLead && (
                <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/20 space-y-3.5 animate-fadeIn">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-xs text-white">Chỉnh sửa trạng thái phễu: <span className="text-emerald-400 font-extrabold">{focusedLead.name}</span></h4>
                    <button onClick={() => setFocusedLead(null)} className="text-slate-400 hover:text-white font-mono text-[9px] hover:scale-105 bg-slate-800 px-1 rounded">&times; ĐÓNG</button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">TRẠNG THÁI TIẾN TRÌNH</label>
                      <select 
                        value={focusedLead.status}
                        onChange={(e: any) => {
                          const updated = { ...focusedLead, status: e.target.value };
                          setFocusedLead(updated);
                          setLeads(prev => prev.map(item => item.id === focusedLead.id ? { ...item, status: e.target.value } : item));
                        }}
                        className="w-full bg-[#131a2c] text-xs border border-slate-800 rounded px-2.5 py-1.5 text-slate-300"
                      >
                        <option value="new">TIẾP CẬN MỚI (NEW)</option>
                        <option value="contacted">ĐÃ LIÊN LẠC</option>
                        <option value="interested">ƯA THÍCH (INTERESTED)</option>
                        <option value="not_interested">KHÔNG QUAN TÂM</option>
                        <option value="closed">CHỐT HỢP ĐỒNG</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">ĐÁNH GIÁ 1-5 SAO</label>
                      <input 
                        type="number" 
                        min="1" 
                        max="5"
                        value={focusedLead.rating || 3}
                        onChange={(e) => {
                          const val = parseInt(e.target.value);
                          const updated = { ...focusedLead, rating: val };
                          setFocusedLead(updated);
                          setLeads(prev => prev.map(item => item.id === focusedLead.id ? { ...item, rating: val } : item));
                        }}
                        className="w-full bg-[#131a2c] text-xs border border-slate-800 rounded px-2.5 py-1.5 text-white"
                      />
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: SYSTEM BYPASS (CMD)                                              */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'ai-command' && (
            <div className="space-y-6">
              
              <div className="p-4 rounded-xl bg-slate-900 border border-amber-500/20 flex items-start space-x-3.5 shadow-md">
                <ShieldAlert className="w-8 h-8 text-amber-500 shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <h3 className="text-xs font-display font-extrabold text-amber-400 uppercase tracking-widest">Kênh Chuyển Tiếp bypass thô [SYSTEM_BYPASS]</h3>
                  <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                    Công cụ bypass cao cấp tối ưu dành riêng cho sếp Trần Tuấn Anh. Cho phép bóc tách và định hướng lệnh thô gửi thẳng về localhost đại bản doanh port 5001 qua trung gian ngrok bảo mật.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                
                {/* Inputs block */}
                <div className="p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex flex-col justify-between">
                  <div className="space-y-4">
                    <h3 className="font-display font-bold text-white text-xs uppercase tracking-wider">Cấu Hình Proxy URL</h3>
                    <div>
                      <label className="block text-[9px] font-mono text-slate-500 mb-1">NGROK ENDPOINT LIVE</label>
                      <input 
                        type="text" 
                        value={customNgrok}
                        onChange={(e) => setCustomNgrok(e.target.value)}
                        placeholder="https://abc-123.ngrok-free.app/execute" 
                        className="w-full bg-[#131a2c] text-[11px] text-blue-300 font-mono border border-slate-850 rounded px-2.5 py-1.5 focus:outline-none"
                      />
                    </div>
                  </div>
                  <div className="pt-3 border-t border-slate-800/40 text-[9px] font-mono text-slate-500">
                    Sống quyền lực và tình cảm cùng anh Tuấn Anh CRM.
                  </div>
                </div>

                {/* Main CLI outputs console */}
                <div className="md:col-span-2 p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex flex-col h-[380px] justify-between">
                  <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 select-none pb-2 border-b border-indigo-500/10">
                    <span>REMOTE SYSTEM LOGS</span>
                    <span className="text-emerald-400 animate-pulse">● ROUTE ACTIVE</span>
                  </div>

                  {/* Shell lines */}
                  <div className="flex-1 bg-black p-3.5 rounded-lg overflow-y-auto font-mono text-[10px] space-y-2.5 scrollbar my-3 max-h-[250px]">
                    {bypassConsole.map((log, idx) => (
                      <div key={idx}>
                        <div className="flex justify-between text-slate-600 text-[8px] border-b border-slate-950 pb-0.5">
                          <span>{log.type === 'input' ? '⟫ INPUT DIRECTIVE' : '⟫ COMMAND RESULT'}</span>
                          <span>{log.time}</span>
                        </div>
                        <p className={log.type === 'error' ? 'text-rose-500' : log.type === 'input' ? 'text-emerald-400' : 'text-slate-300'}>
                          {log.text}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Input CLI footer command */}
                  <form onSubmit={handleExecuteBypass} className="flex gap-2">
                    <span className="text-emerald-400 text-xs font-bold pt-1">❯</span>
                    <input 
                      type="text" 
                      value={bypassCommand}
                      onChange={(e) => setBypassCommand(e.target.value)}
                      placeholder="vd: Tạo excel báo cáo doanh số, quét thông số CRO..."
                      className="flex-1 bg-black text-white font-mono text-[11px] border border-slate-800 rounded px-3 py-1.5 focus:outline-none"
                    />
                    <button type="submit" className="px-4.5 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-extrabold hover:bg-emerald-400">GỬI</button>
                  </form>
                </div>

              </div>

            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: KNOWLEDGE CENTER                                                 */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'knowledge' && (
            <div className="space-y-6">
              
              <div className="flex items-center space-x-3.5 bg-slate-950/20 p-3 rounded-lg border border-slate-800/60">
                <Search className="w-4 h-4 text-slate-500 ml-1.5" />
                <input 
                  type="text" 
                  value={searchDocQuery}
                  onChange={(e) => setSearchDocQuery(e.target.value)}
                  placeholder="Tra cứu bài viết kỹ thuật phễu, bypass, tối ưu CRO..."
                  className="flex-1 bg-transparent border-none text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {knowledgeBase.filter(d => d.title.toLowerCase().includes(searchDocQuery.toLowerCase()) || d.summary.toLowerCase().includes(searchDocQuery.toLowerCase())).map((doc, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex flex-col justify-between h-52 hover:border-emerald-500/20 transition-all">
                    <div>
                      <div className="flex justify-between items-center text-[9px] font-mono text-slate-500 uppercase">
                        <span>{doc.category}</span>
                        <span>{doc.author}</span>
                      </div>
                      <h4 className="font-bold text-xs text-slate-100 mt-2.5">{doc.title}</h4>
                      <p className="text-[10px] text-slate-400 mt-1 lines-clamp-3 leading-relaxed">{doc.summary}</p>
                    </div>
                    <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-850/60 mt-2">
                      {doc.tags.map((t, i) => (
                        <span key={i} className="text-[8px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">#{t}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: KPIS ANALYTICS                                                   */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'kpis' && (
            <KPIManager 
              currentUser={currentUser!}
              kpis={kpis}
              setKpis={setKPIs}
              onAddNotification={(title, content, type) => {
                const notif = {
                  id: 'notif_' + Date.now(),
                  title,
                  content,
                  type,
                  time: 'Vừa xong',
                  read: false
                };
                setNotifications(prev => [notif, ...prev]);
              }}
            />
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: AUTOMATION                                                       */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'automation' && (
            <div className="space-y-6">
              
              <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md">
                <h3 className="font-display font-extrabold text-white text-xs uppercase tracking-wider mb-4 pb-1 border-b border-slate-800/30">Cấu Hình Quy Trình Tự Động Hóa Live</h3>
                
                <form onSubmit={handleAddRule} className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">ĐIỀU KIỆN KÍCH HOẠT (TRIGGER)</label>
                    <input 
                      type="text" 
                      required 
                      value={newRuleTrigger}
                      onChange={(e) => setNewRuleTrigger(e.target.value)}
                      placeholder="Khi có lead rated 5 sao trên Zalo..." 
                      className="w-full bg-[#131a2c] text-xs border border-slate-800 rounded px-2.5 py-1.5 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">HÀNH ĐỘNG LIÊN ĐỚI (ACTION)</label>
                    <input 
                      type="text" 
                      required 
                      value={newRuleAction}
                      onChange={(e) => setNewRuleAction(e.target.value)}
                      placeholder="Forward tới NGROK bypass + Gửi mail cảnh báo Sếp..." 
                      className="w-full bg-[#131a2c] text-xs border border-slate-800 rounded px-2.5 py-1.5 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="md:col-span-2 flex justify-end">
                    <button type="submit" className="px-5 py-1.5 bg-emerald-500 text-slate-950 rounded text-xs font-bold hover:bg-emerald-400 transition shadow">
                      KÍCH HOẠT QUY TRÌNH
                    </button>
                  </div>
                </form>

                <div className="space-y-3 pt-3 border-t border-slate-850">
                  {automationRules.map(rule => (
                    <div key={rule.id} className="p-3 bg-slate-950/40 rounded-lg border border-slate-800/50 flex justify-between items-center">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                          <p className="text-xs font-extrabold text-white">{rule.trigger}</p>
                        </div>
                        <p className="text-[10px] text-slate-450 mt-1 pl-3.5 italic text-emerald-400/95 font-mono">➡ Action: {rule.action}</p>
                      </div>
                      <button 
                        onClick={() => {
                          setAutomationRules(prev => prev.map(item => item.id === rule.id ? { ...item, active: !item.active } : item));
                        }}
                        className={`px-2.5 py-0.5 rounded text-[10px] font-mono tracking-wider font-extrabold transition ${
                          rule.active ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/25' : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {rule.active ? 'ACTIVE' : 'INACTIVE'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: NOTIFICATIONS                                                    */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'notifications' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-slate-850">
                <h3 className="font-display font-bold text-white text-xs uppercase tracking-wider">Hộp Thư Thông Báo OS</h3>
                <button 
                  onClick={() => {
                    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
                    setCurrentNotification(null);
                  }}
                  className="text-slate-500 hover:text-white font-mono text-[9px] hover:scale-105"
                >
                  XÓA TẤT CẢ CHƯA ĐỌC
                </button>
              </div>

              <div className="space-y-3.5">
                {Array.from(new Map(notifications.map(n => [n.id, n])).values()).map(n => (
                  <div key={n.id} className={`p-3 rounded-lg border flex justify-between items-center transition ${
                    n.read ? 'bg-slate-900/10 border-slate-850 text-slate-400' : 'bg-emerald-500/5 border-emerald-500/20 text-slate-200'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${n.read ? 'bg-slate-600' : 'bg-emerald-400 animate-ping'}`} />
                      <div>
                        <h4 className="font-bold text-xs text-white">{n.title}</h4>
                        <p className="text-[10px] text-slate-400 mt-1">{n.message}</p>
                      </div>
                    </div>
                    <span className="text-[9px] font-mono text-slate-500">{new Date(n.timestamp).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: FILES                                                            */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'files' && (
            <div className="space-y-6">
              
              <div className="p-6 border border-dashed border-slate-800 rounded-xl bg-slate-900/10 text-center space-y-3 hover:border-emerald-500/30 transition-all select-none">
                <FileText className="w-10 h-10 text-slate-600 mx-auto" />
                <div>
                  <p className="text-xs font-bold text-white">Bấm hoặc kéo thả tài liệu vào đây để phân tích AI</p>
                  <p className="text-[10px] text-slate-500 mt-1">Hỗ trợ Excel, PDF, PNG thô (Tối đa 12MB)</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {fileVault.map((file, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md flex flex-col justify-between h-48">
                    <div>
                      <div className="flex justify-between items-center text-[10px] font-mono text-slate-500">
                        <span>{file.type.toUpperCase()}</span>
                        <span>{file.size}</span>
                      </div>
                      <h4 className="font-bold text-xs text-white mt-2.5 truncate">{file.name}</h4>
                      <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed bg-[#0c101a] p-2 rounded-lg border border-slate-900 max-h-[70px] overflow-y-auto font-mono text-[9px]">{file.aiSummary}</p>
                    </div>
                    <span className="text-[8px] font-mono text-emerald-400 block font-bold uppercase tracking-widest mt-2">CLASSIFY: {file.tag}</span>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: CHATBOT DUYEN                                                    */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'chatbot-duyen' && (
            <ChatbotDuyen />
          )}

          {/* --------------------------------------------------------------------- */}
          {/* TAB: SETTINGS                                                         */}
          {/* --------------------------------------------------------------------- */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              
              <div className="p-4.5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md">
                <h3 className="font-display font-extrabold text-white text-xs uppercase tracking-wider mb-4 pb-1 border-b border-slate-800/30">Cài Đặt Cấu Hình OS</h3>
                <div className="space-y-4">
                  <div className="bg-slate-950/40 p-4.5 rounded-lg border border-slate-900 space-y-4.5">
                    <p className="text-xs font-bold text-white">Chế độ đồng bộ Appwrite Cloud</p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 font-mono text-[11px]">Đường kết nối chính:</span>
                        <span className="bg-slate-800 text-emerald-400 font-mono text-[10px] px-2.5 py-0.5 rounded font-bold">READY (Offline Built-in)</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 font-mono text-[11px]">Tin nhắn Zalo Webhook lắng nghe thô:</span>
                        <span className="text-slate-200 font-mono font-bold">{zaloMsgs.length} tin nhắn</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-950/40 p-4.5 rounded-lg border border-slate-900 space-y-4">
                    <p className="text-xs font-bold text-white">Chỉnh màu chủ đề cho giao diện (Theme Customization)</p>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                      {[
                        { id: 'midnight', name: 'Midnight Blue (Mặc định)', color: 'bg-[#0b0f19]' },
                        { id: 'emerald', name: 'Classic Emerald (Rừng Ngọc)', color: 'bg-[#05140f]' },
                        { id: 'violet', name: 'Premium Violet (Lục bảo tím)', color: 'bg-[#0f0a1c]' },
                        { id: 'solarized', name: 'Warm Sand (Trà Cát)', color: 'bg-[#1a1c17]' }
                      ].map(theme => (
                        <button
                          key={theme.id}
                          type="button"
                          onClick={() => {
                            setThemeColor(theme.id as any);
                            localStorage.setItem('tdn_theme_color', theme.id);
                          }}
                          className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${
                            themeColor === theme.id 
                              ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold' 
                              : 'border-slate-800 bg-slate-900/30 text-slate-400 hover:text-white'
                          }`}
                        >
                          <span className={`w-6 h-6 rounded-full ${theme.color} border border-white/10`} />
                          <span className="text-[10px] font-semibold text-center leading-tight">{theme.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-slate-950/40 p-4.5 rounded-lg border border-[#ef4444]/10 space-y-4">
                    <p className="text-xs font-bold text-red-400">Xóa dữ liệu bộ nhớ Cache</p>
                    <p className="text-[10px] text-slate-450 leading-relaxed">
                      Lưu ý: Bấm thanh lọc sẽ reset toàn bộ cài đặt `localStorage` và nạp lại cấu hình thô từ Appwrite Cloud DB.
                    </p>
                    <button 
                      onClick={() => {
                        localStorage.clear();
                        alert('Độ ưu tiên xóa cache thành công! Vui lòng refresh lại cửa sổ.');
                        window.location.reload();
                      }}
                      className="px-4 py-1.5 bg-rose-500 hover:bg-rose-650 text-slate-950 rounded text-xs font-mono font-extrabold transition cursor-pointer"
                    >
                      DỌN SẠCH CACHE LOCALDB
                    </button>
                  </div>
                </div>
              </div>

            </div>
          )}
          </>)}
        </div>

      </main>

    </div>
  );
}
