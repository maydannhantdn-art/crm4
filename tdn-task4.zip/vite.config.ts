import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';

// For Vite in Express middleware mode, we only need to provide plugins and basic directory instructions
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      'cross-fetch': path.resolve(__dirname, 'src/lib/fetch-ponyfill.ts')
    }
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
  server: {
    port: 3000,
    host: '0.0.0.0',
    allowedHosts: true,
    hmr: false // Disable HMR as instructed by the platform constraints
  }
});
