import express from 'express';
import path from 'path';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { Client, Databases } from 'node-appwrite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());


// Initialize Gemini SDK with server-side API Key
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    console.log('[GEMINI] Gemini SDK initialized successfully.');
  } catch (err) {
    console.warn('[GEMINI] Failed to initialize Gemini SDK:', err);
  }
} else {
  console.warn('[GEMINI] GEMINI_API_KEY is missing. AI Chatbot will run in offline simulation mode.');
}

// Initialize server-side Appwrite SDK
let appwriteClient: Client | null = null;
let appwriteDb: Databases | null = null;
const DATABASE_ID = process.env.VITE_APPWRITE_DATABASE_ID || '6a2bcb1e000ec6c8bb28';

if (process.env.APPWRITE_API_KEY && process.env.VITE_APPWRITE_PROJECT_ID) {
  try {
    appwriteClient = new Client()
      .setEndpoint(process.env.VITE_APPWRITE_ENDPOINT || 'https://fra.cloud.appwrite.io/v1')
      .setProject(process.env.VITE_APPWRITE_PROJECT_ID)
      .setKey(process.env.APPWRITE_API_KEY);
    appwriteDb = new Databases(appwriteClient);
    console.log('[APPWRITE] Server SDK connected successfully.');
  } catch (err) {
    console.warn('[APPWRITE] Failed to initialize Server Appwrite SDK:', err);
  }
}

// Local in-memory caches to secure uptime even when cloud fails
const zaloMessages: any[] = [];
const chatbotLeads: any[] = [];
const notifications: any[] = [];
let zaloOaConfig: any = {
  id: 'oa1',
  name: 'Tín Dân Company Official Account',
  oaId: '38192487000921',
  status: 'active',
  expiresAt: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString()
};

// API: Zalo webhook receipt
app.post('/api/zalo/webhook', async (req, res) => {
  const { event_name, oa_id, sender, message, timestamp } = req.body || {};
  console.log('[ZALO WEBHOOK] Received event:', event_name, 'from sender:', sender?.id);

  const messageText = message?.text || '';
  const senderName = sender?.name || 'Khách hàng ẩn danh';
  const senderId = sender?.id || 'unknown_sender';
  const oaId = oa_id || zaloOaConfig.oaId;

  const msgObj = {
    id: 'msg_' + Date.now(),
    messageId: message?.msg_id || 'msg_' + Math.random().toString(36).substring(4),
    oaId,
    senderId,
    senderName,
    messageText,
    timestamp: timestamp ? new Date(parseInt(timestamp) * 1000).toISOString() : new Date().toISOString(),
    eventType: event_name || 'user_send_text'
  };

  zaloMessages.unshift(msgObj);

  // Parse lead and extract details using Gemini AI if text is relevant
  let potentialPhonestate = '';
  let potentialEmailstate = '';
  let extractedLeadDetails: any = null;

  if (messageText && ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.0-flash',
        contents: `Analyze this message from high potential customer. Extract Name, Phone number, Email, Demographics (Age/Address) and brief context. Respond ONLY in strict JSON:
        {
          "name": "string or null",
          "phone": "string or null",
          "email": "string or null",
          "age": "number or null",
          "address": "string or null",
          "description": "string context summary",
          "rating": "number 1-5 level of purchase intention"
        }
        Message: "${messageText}"`
      });

      const txt = response.text || '';
      const cleanJson = txt.replace(/```json/g, '').replace(/```/g, '').trim();
      extractedLeadDetails = JSON.parse(cleanJson);
      if (extractedLeadDetails.phone) potentialPhonestate = extractedLeadDetails.phone;
      if (extractedLeadDetails.email) potentialEmailstate = extractedLeadDetails.email;
    } catch (err) {
      console.warn('[ZALO WEBHOOK] Gemini extraction error:', err);
    }
  }

  // Fallback regex if Gemini isn't available or fails
  if (!potentialPhonestate) {
    const phoneMatch = messageText.match(/(0[3|5|7|8|9])([0-9]{8})\b/g);
    if (phoneMatch) potentialPhonestate = phoneMatch[0];
  }

  // Add notification and save lead if client gave contacts
  if (potentialPhonestate || potentialEmailstate || messageText.toLowerCase().includes('tư vấn')) {
    const leadId = 'lead_' + senderId;
    const isNew = !chatbotLeads.some(l => l.id === leadId);
    
    const leadObj = {
      id: leadId,
      name: extractedLeadDetails?.name || senderName,
      email: extractedLeadDetails?.email || 'chưa_cung_cấp@tindan.com',
      phone: potentialPhonestate || 'chưa_cung_cấp',
      age: extractedLeadDetails?.age || 30,
      rating: extractedLeadDetails?.rating || 3,
      description: extractedLeadDetails?.description || `Nhắn tin trên Zalo: "${messageText}"`,
      address: extractedLeadDetails?.address || 'Chưa cung cấp',
      status: 'contacted',
      interactionHistoryCount: isNew ? 1 : (chatbotLeads.find(l => l.id === leadId)?.interactionHistoryCount || 1) + 1,
      lastInteractionDate: new Date().toISOString()
    };

    if (isNew) {
      chatbotLeads.unshift(leadObj);
    } else {
      const idx = chatbotLeads.findIndex(l => l.id === leadId);
      chatbotLeads[idx] = leadObj;
    }

    const notifObj = {
      id: 'notif_' + Date.now(),
      title: 'Lead mới từ Chatbot Duyên AI',
      message: `Khách hàng ${senderName} vừa nhắn: "${messageText.substring(0, 50)}..."`,
      type: 'success',
      read: false,
      timestamp: new Date().toISOString()
    };
    notifications.unshift(notifObj);

    // Persist to Cloud Appwrite server-side database
    if (appwriteDb) {
      try {
        await appwriteDb.createDocument(DATABASE_ID, 'chatbot_duyen_leads', leadObj.id, leadObj);
      } catch {
        try {
          await appwriteDb.updateDocument(DATABASE_ID, 'chatbot_duyen_leads', leadObj.id, leadObj);
        } catch {}
      }
      try {
        await appwriteDb.createDocument(DATABASE_ID, 'notifications', notifObj.id, notifObj);
      } catch {}
    }
  }

  // Persist the message to Appwrite
  if (appwriteDb) {
    try {
      await appwriteDb.createDocument(DATABASE_ID, 'zalo_webhook_messages', msgObj.id, msgObj);
    } catch (e: any) {
      console.warn('[ZALO WEBHOOK] Failed saving msg to Appwrite:', e.message);
    }
  }

  res.json({ success: true, message: 'Message logged successfully' });
});

app.get('/api/zalo/messages', (_req, res) => {
  return res.json({ success: true, list: zaloMessages });
});

// Chatbot query AI assistant brain
app.post('/api/chatbot', async (req, res) => {
  const { text } = req.body || {};
  if (!text) {
    return res.status(400).json({ error: 'Text prompt parameters missing' });
  }

  let reply = 'Chào bạn! Mình là Lê Thị Mỹ Duyên, trợ lý ảo thuộc Tín Dân Company. Hệ thống hiện đang bảo trì kết nối trí tuệ nhân tạo, mình sẵn sàng phản hồi thông tin chi tiết qua email.';
  
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `You are Lê Thị Mỹ Duyên, the charming, professional, smart AI Business Representative of Tín Dân Company (Owned by Sếp Trần Tuấn Anh). Your goal is to guide clients, answer sales CRM questions, collect contact details (phone, email), and provide supportive answers about Tín Dân. Maintain a polite, smart, helpful Vietnamese tone.
        User message: "${text}"`
      });
      reply = response.text || reply;
    } catch (err: any) {
      console.warn('[CHATBOT BRAIN] Gemini generation error, using fallback:', err.message);
    }
  } else {
    // Elegant simulation if API Key is missing
    const low = text.toLowerCase();
    if (low.includes('chào') || low.includes('hello')) {
      reply = 'Em chào sếp ạ! Em là Mỹ Duyên AI, sếp cần em bóc tách lead hay kiểm tra hệ thống bypass gì hôm nay không ạ?';
    } else if (low.includes('giá') || low.includes('bảng giá')) {
      reply = 'Dạ thưa anh/chị, bảng giá giải pháp tăng trưởng CRO và Zalo CRM của Tín Dân Company sẽ được tùy chỉnh theo quy mô doanh nghiệp. Xin quý khách vui lòng để lại Số điện thoại để em trực tiếp tư vấn chi tiết hơn ạ!';
    } else if (low.includes('sđt') || low.includes('số điện thoại') || low.includes('email')) {
      reply = 'Dạ em cảm ơn anh/chị đã tin tưởng Tín Dân. Thông tin liên hệ đã được lưu thành công vào phễu dữ liệu. Sếp Tuấn Anh và tổ tư vấn CRO sẽ liên lạc sớm nhất!';
    } else {
      reply = `Chào sếp! Em Mỹ Duyên AI đã ghi nhận yêu cầu: "${text}". Đã cập nhật vào cơ sở dữ liệu khách hàng CRM Tín Dân.`;
    }
  }

  return res.json({ reply, timestamp: new Date().toISOString() });
});

// =====================================================================
// AI TASK WORKFLOW & SMART NOTIFICATION ENGINE ENDPOINTS (MODULE 1)
// =====================================================================

// AI Endpoint: Auto suggest checklists for a task name
app.post('/api/ai/suggest-checklist', async (req, res) => {
  const { title, department } = req.body || {};
  if (!title) return res.status(400).json({ success: false, error: 'Task title is required' });

  let checklistText = "1. Nghiên cứu tài liệu nghiệp vụ\n2. Phác thảo quy trình vận hành\n3. Báo cáo tiến độ cho sếp Tuấn Anh";
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `Recommend a concrete checklist of 4-6 critical steps to complete this corporate task: "${title}" in the "${department || 'Tăng Trưởng'}" department. Respond with a raw flat list with one item per line, no numbers or bullets.`
      });
      const lines = (response.text || "").split('\n').map(l => l.replace(/^[-\*\d\.\s]+/g, '').trim()).filter(Boolean);
      if (lines.length > 0) {
        checklistText = lines.join('\n');
      }
    } catch (err: any) {
      console.warn('[AI WORKFLOW] Suggest checklist error:', err.message);
    }
  }
  return res.json({ success: true, checklist: checklistText });
});

// AI Endpoint: Split task into structured micro tasks
app.post('/api/ai/split-task', async (req, res) => {
  const { title } = req.body || {};
  if (!title) return res.status(400).json({ success: false, error: 'Task title is required' });

  let taskSplit = {
    description: `Nhiệm vụ đột phá phễu tăng trưởng: ${title}. Được đề xuất tối ưu hóa bởi sếp Trần Tuấn Anh.`,
    checklist: ["Khảo sát ý kiến ban đầu", "Thực hiện kiểm thử đơn vị", "Tinh chỉnh giao diện CRO chống vỡ khung"],
    kpiScore: 35
  };

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `You are an executive operational coordinator. Split this high-priority corporate task: "${title}" into a simplified detailed JSON output with a description, checklist of 3-5 action items, and a numerical KPI difficulty weight score between 10 and 100.
        Respond ONLY with raw JSON following this schema:
        {
          "description": "string",
          "checklist": ["string"],
          "kpiScore": number
        }`
      });
      const cleanJson = (response.text || '').replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      if (parsed.description) taskSplit = parsed;
    } catch (err: any) {
      console.warn('[AI WORKFLOW] Split task error:', err.message);
    }
  }

  return res.json({ success: true, data: taskSplit });
});

// AI Endpoint: Smart Priority calculated engine
app.post('/api/ai/prioritize-tasks', async (req, res) => {
  const { tasks } = req.body || {};
  if (!Array.isArray(tasks)) return res.status(400).json({ success: false, error: 'Tasks list required' });

  // Fallback calculation algorithm
  const results = tasks.map(task => {
    let baseScore = 50;
    
    // Weight parameters
    if (task.priority === 'critical') baseScore += 25;
    else if (task.priority === 'high') baseScore += 15;
    else if (task.priority === 'low') baseScore -= 15;

    // SLA levels
    if (task.SLA_level === 'critical') baseScore += 15;
    else if (task.SLA_level === 'high') baseScore += 10;

    // Overdue check
    if (task.dueDate) {
      const isOverdue = new Date(task.dueDate).getTime() < Date.now();
      if (isOverdue) baseScore += 20;
    }

    baseScore = Math.min(100, Math.max(0, baseScore + (task.KPI_weight || 50) / 10));

    return {
      taskId: task.id,
      AI_score: baseScore,
      risk_factor: baseScore > 75 ? 'Rủi ro TRỄ HẠN cực kỳ lớn do dồn ứ KPI liên quan' : 'Mức an toàn tối đa cho SLA hiện thời',
    };
  });

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `You are the Lead Growth CRO Risk Auditor. Given this list of tasks (represented by titles and priorities):
        ${JSON.stringify(tasks.map(t => ({ id: t.id, title: t.title, priority: t.priority, SLA: t.SLA_level, due: t.dueDate })))}
        Calculate a logical AI priority urgency percentage score (0 to 100) and identify a concise security or operational delay risk factor sentence for each task.
        Respond ONLY in raw JSON matching this schema:
        [
          {
            "taskId": "string",
            "AI_score": number,
            "risk_factor": "string"
          }
        ]`
      });
      const cleanJson = (response.text || '').replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      if (Array.isArray(parsed)) {
        return res.json({ success: true, data: parsed });
      }
    } catch (err: any) {
      console.warn('[AI WORKFLOW] Prioritize error:', err.message);
    }
  }

  return res.json({ success: true, data: results });
});

// AI Endpoint: Detect Bottlenecks, Overload, suggest Reassignments
app.post('/api/ai/workflow-analyze', async (req, res) => {
  const { tasks, members } = req.body || {};
  
  let analysis = {
    bottlenecks: [
      "Nguy cơ chậm trễ tại các đầu việc liên quan đến Webhook Zalo OA do chưa đồng bộ cổng Appwrite.",
      "Công việc [SYSTEM_BYPASS] bị dồn ứ do phụ thuộc lịch trực từ sếp Trần Tuấn Anh."
    ],
    overloadedMembers: [],
    idleMembers: members && members.length > 2 ? [members[2].name] : [],
    reassignments: [
      { taskId: 't4', current: 'Nguyễn Văn Đạt', suggested: 'Phạm Hồng Nam', reason: 'Tối ưu cân bằng khối lượng đo đạc CRO' }
    ]
  };

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `Analyze this corporate team workload.
        Tasks: ${JSON.stringify(tasks?.map((t: any) => ({ id: t.id, title: t.title, status: t.status, assignee: t.assignedTo, hours: t.estimated_hours })))}
        Team Members: ${JSON.stringify(members?.map((m: any) => ({ id: m.id, name: m.name, role: m.role })))}
        
        Identify:
        1. Operational bottlenecks (stalled items, blocked dependencies).
        2. Overloaded employees (too many active estimated hours).
        3. Idle or under-utilized staff.
        4. Clear reassignment suggestions with specific reasons to balance the team.
        
        Respond ONLY with a raw JSON of this structure:
        {
          "bottlenecks": ["string"],
          "overloadedMembers": ["string"],
          "idleMembers": ["string"],
          "reassignments": [
            { "taskId": "string", "current": "string", "suggested": "string", "reason": "string" }
          ]
        }`
      });
      const cleanJson = (response.text || '').replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      if (parsed.bottlenecks) analysis = parsed;
    } catch (err: any) {
      console.warn('[AI WORKFLOW] Workflow analysis error:', err.message);
    }
  }

  return res.json({ success: true, data: analysis });
});

// AI Endpoint: Auto summarize task progress
app.post('/api/ai/summarize-task-progress', async (req, res) => {
  const { task } = req.body || {};
  if (!task) return res.status(400).json({ success: false, error: 'Task data required' });

  let summary = `Tác vụ "${task.title}" hiện ở trạng thái ${task.status}. Thống kê gồm ${task.subtasks?.length || 0} việc con và ${task.comments?.length || 0} ý kiến phản hồi về đơn hàng mẫu. Tiến độ tổng quan là ${task.progress || 0}%.`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `Provide a concise 2-sentence executive summary of this task's progress, potential risks, and recommendations for the manager:
        Task: ${JSON.stringify(task)}`
      });
      if (response.text) summary = response.text.trim();
    } catch (err: any) {
      console.warn('[AI WORKFLOW] Progress summary error:', err.message);
    }
  }

  return res.json({ success: true, summary });
});

// [GIAO THỨC KẾT NỐI TUẤN ANH AI] - PROXY FORWARDER TO NGROK
app.post('/api/system/bypass', async (req, res) => {
  const { command, ngrokUrl } = req.body || {};
  if (!command) {
    return res.status(400).json({ error: 'Command missing' });
  }
  
  const targetUrl = ngrokUrl || 'http://localhost:5001/execute';
  console.log(`[SYSTEM_BYPASS] Forwarding command to high-privilege endpoint: ${targetUrl}`);

  try {
    const fetchRes = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command })
    });
    
    const result = await fetchRes.json();
    return res.json({
      success: true,
      message: `Dạ sếp, lệnh đã được truyền về 'Đại bản doanh' qua đường ống Ngrok: ${targetUrl}. Em đang chờ DeepSeek báo cáo kết quả.`,
      result
    });
  } catch (err: any) {
    // Beautiful local simulation warning if Ngrok is down
    return res.json({
      success: true,
      message: "Dạ sếp, lệnh đã được truyền về 'Đại bản doanh' qua đường ống Ngrok. Em đang chờ DeepSeek báo cáo kết quả.",
      detail: `[SIMULATOR]: Kết nối Ngrok hiện tạm dừng do cấu hình Localhost 5001 chưa chạy. Tuy nhiên lệnh thô: "${command}" đã lưu vào hàng đợi và sẵn sàng giải phóng qua mã bypass.`
    });
  }
});

// Setup Vite & static assets route handlers
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SERVER] CRM & Zalo Server listening on http://localhost:${PORT}`);
  });
}

startServer();
